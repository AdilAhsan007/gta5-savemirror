/* Thin platform layer: PS4 implementations are at the end of main.c,
 * host-test implementations are in test/host_platform.h. */
#ifndef SM_PLATFORM_H
#define SM_PLATFORM_H
#include <stdint.h>
#include <sys/types.h>
typedef struct { char on[256]; char from[256]; } sm_mount_t;
void     platform_notify(const char *msg);
unsigned platform_fw_version(void);
int      platform_is_mountpoint(const char *path);
int      platform_mounts(sm_mount_t *out, int max);
ssize_t  platform_write(int fd, const void *buf, size_t n);
void     platform_after_chunk(const char *src, int64_t done);
#endif
