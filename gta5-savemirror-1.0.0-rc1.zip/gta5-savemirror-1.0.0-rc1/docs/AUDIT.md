# Code audit (1.0.0 -> 1.0.0-rc1)

Every write in `src/main.c` (checked with grep):

| Line kind | Target |
|---|---|
| `open(dst, O_WRONLY\|O_CREAT\|O_EXCL)` in `copy_file` | new files inside a `.partial` snapshot, the Apollo staging temp folder, or `/data/payloads/gta5_savemirror.elf.new` – never an existing file |
| `fopen(..., "w")` | `MANIFEST.sha256`, `INFO.txt` (inside `.partial`), `/data/savemirror/last_<user>.txt`, `/data/savemirror/instance.pid` |
| `fopen(..., "a")` | the two log files |
| `open(LOCK_FILE, O_RDWR\|O_CREAT)` | `/data/savemirror/instance.lock` |

The console save folder is only opened with `O_RDONLY`/`opendir`/`stat`.
Nothing builds a path under `PS4/APOLLO`.

## Save discovery

- Location `/user/home/<user>/savedata/CUSA00419/` – confirmed by Apollo's
  source (`SAVES_PATH_HDD "/user/home/%08x/savedata/"`, then `sdimg_<dir>`
  and `<dir>.bin`).
- All slots are copied: every regular file in that folder. A snapshot is only
  taken when every `sdimg_<X>` has its `<X>.bin` and vice versa (T11).
- User IDs: every 8-hex-digit folder in `/user/home` that has a CUSA00419
  save folder; each user has its own snapshot folder.
- Readable while GTA V runs? The encrypted files are ordinary files. The
  payload never mounts them. Not verified on a console.

## Live consistency

- The game writes through a mounted PFS image; whether the image file on disk
  is fully updated during a 90 s quiet period is **unknown**. LIVE snapshots
  are labelled best effort, REST snapshots are taken only when no
  `/mnt/sandbox/CUSA00419_*` mount and no mount of the save image exists.
- Several autosaves less than 90 s apart become one snapshot (by design).
- Change detection: names/sizes/mtimes before and after the copy, plus a
  second full SHA-256 read of the source (catches same-size, same-mtime
  rewrites, T10), plus game/mount state before and after.
- The copy on USB is re-read and must match (catches bad writes).
- What cannot be detected: a save that was internally inconsistent at the
  moment it was read but did not change afterwards. That is the LIVE risk.

## USB

- Writes go through the PS4 kernel's own exFAT driver (normal
  `open`/`write`), the same way Apollo writes.
- A drive is used only if `/mnt/usbN` is an actual mount point (statfs
  `f_mntonname` equals the path) **and** `SaveMirror/ENABLE_SAVEMIRROR.txt`
  is a regular file on it (T02, T03). Version 1.0.0 skipped the mount-point
  check, so an empty `/mnt/usbN` on internal storage could in theory have
  been used if a marker existed there.
- Disconnect/write error: the attempt is discarded and the `.partial` folder
  removed (T09). If the drive is gone, removal happens on the next prune.
- Commit: files fsynced → manifest + INFO fsynced (INFO's last line is
  `status=complete`) → rename. exFAT rename is not guaranteed atomic on
  power loss, so a folder only counts as a snapshot if INFO ends with
  `status=complete`; others are never counted or pruned.

## Retention and safety

- Newest 40, newest per day for 90 days, always the newest REST (T19).
  The newest snapshot is always kept, so the last backup is never deleted.
- Only names matching `S######_YYYY-MM-DD_hh-mm-ss_REST|LIVE` are ever
  deleted. Fixed: 1.0.0 had no sequence numbers and sorted by clock time.
- Free space: refuses if free − snapshot size < 2048 MB (T18).
- Lock: `flock` on `/data/savemirror/instance.lock` (released by the kernel
  if the payload dies), heartbeat-file fallback (T06).

## Background operation

- Independent of GTA V's process: yes (payload, not plugin). It does run on
  a thread inside a GoldHEN-chosen system process, so 1.0.0's
  `signal()`, `setpriority()` and kernel credential writes were removed.
- AutoRun after reboot: GoldHEN feature, not testable here.
- GoldHEN reloaded without a reboot: a second copy exits because of the lock.

## Bugs found and fixed in this audit

1. `build_mac.sh` used SDK release v0.9 (no 13.52 support).
2. Process-wide side effects on the host system process (see above).
3. No mount-point check for `/mnt/usbN`.
4. CRC32 only; no second read of the source; no re-check of game state.
5. Retention could keep wrong snapshots if the clock jumped; now ordered by
   sequence number.
6. Unpaired slot files could be snapshotted.
7. Found by the new tests during this rewrite: snapshot-name length check
   was off by one, so retention and Apollo staging silently did nothing.
   Fixed before release (T14, T19).
