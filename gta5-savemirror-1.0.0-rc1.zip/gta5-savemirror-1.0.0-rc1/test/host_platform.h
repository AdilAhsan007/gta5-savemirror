/* Host (Linux) implementation of src/platform.h, used ONLY by the tests.
 * It simulates the PS4 pieces the payload depends on:
 *   ROOT/mnt/usbN/.fake_mountpoint  -> /mnt/usbN counts as a mounted drive
 *   ROOT/fake_mounts.txt            -> "from on" lines = the mount table
 *   SM_FAKE_FW (env, hex)           -> firmware version (default 0x13520000)
 *   ROOT/hooks/fail_write           -> next write() fails (drive pulled)
 *   ROOT/hooks/mutate_source        -> source changes mid-copy, mtime kept
 */
#include <sys/statfs.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

void platform_notify(const char *msg) {
  FILE *f = fopen(ROOT "/notify.log", "a");
  if(f) { fprintf(f, "%s\n", msg); fclose(f); }
  printf("[NOTIFY] %s\n", msg);
  fflush(stdout);
}
unsigned platform_fw_version(void) {
  const char *e = getenv("SM_FAKE_FW");
  return e ? (unsigned)strtoul(e, NULL, 16) : 0x13520000u;
}
int platform_is_mountpoint(const char *path) {
  char p[512];
  struct stat st;
  snprintf(p, sizeof p, "%s/.fake_mountpoint", path);
  return stat(p, &st) == 0;
}
int platform_mounts(sm_mount_t *out, int max) {
  FILE *f = fopen(ROOT "/fake_mounts.txt", "r");
  int n = 0;
  if(!f) return 0;
  while(n < max && fscanf(f, "%255s %255s", out[n].from, out[n].on) == 2) n++;
  fclose(f);
  return n;
}
ssize_t platform_write(int fd, const void *b, size_t n) {
  if(access(ROOT "/hooks/fail_write", F_OK) == 0) {
    unlink(ROOT "/hooks/fail_write");
    return -1;                       /* like a pulled USB drive */
  }
  return write(fd, b, n);
}
void platform_after_chunk(const char *src, int64_t done) {
  struct stat st;
  if(done <= 0 || !strstr(src, "/savedata/") ||
     access(ROOT "/hooks/mutate_source", F_OK) != 0) return;
  unlink(ROOT "/hooks/mutate_source");
  stat(src, &st);
  int fd = open(src, O_WRONLY);     /* TEST HOOK ONLY: simulates the game */
  if(fd >= 0) { if(pwrite(fd, "X", 1, 10) != 1) perror("hook"); close(fd); }
  struct timespec ts[2] = {st.st_atim, st.st_mtim};
  utimensat(AT_FDCWD, src, ts, 0);   /* hide the change from size+mtime */
}
