#!/usr/bin/env bash
# Host-side tests for GTA V Save Mirror.
#
# Runs the REAL src/main.c logic on Linux against a simulated PS4 file tree
# (see test/host_platform.h). Passing these tests says nothing about whether
# the payload starts on a real PS4 - that needs the console.
#
# Usage, from the repository root:   test/run_host_tests.sh
# Needs: bash, a C compiler (cc/gcc/clang), sha256sum or shasum, python3.
set -u
cd "$(dirname "$0")/.."
REPO=$(pwd)
F=/tmp/smfake
BIN=/tmp/smhost
BIN_FULL=/tmp/smhost_full
CC=${CC:-cc}
PASS=0; FAIL=0; RESULTS=()

if command -v sha256sum >/dev/null; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
sha() { $SHA "$1" | cut -d' ' -f1; }
tree_hash() { (cd "$1" 2>/dev/null && find . -type f -print0 | sort -z | xargs -0 -r $SHA) | $SHA | cut -d' ' -f1; }

ok()   { PASS=$((PASS+1)); RESULTS+=("PASS  $1"); echo "PASS  $1"; }
bad()  { FAIL=$((FAIL+1)); RESULTS+=("FAIL  $1 -- $2"); echo "FAIL  $1 -- $2"; }
check(){ if eval "$2"; then ok "$1"; else bad "$1" "$3"; fi; }

FLAGS="-DHOST_TEST -DROOT=\"$F\" -DPOLL_SECS=1 -DSTABLE_REST_SECS=2 -DSTABLE_LIVE_SECS=3 -Wall -Werror -Wno-format-truncation -O1"
echo "== building host binaries"
$CC $FLAGS -DMIN_FREE_MB=1 src/main.c src/sha256.c -o $BIN || { echo "build failed"; exit 1; }
$CC $FLAGS -DMIN_FREE_MB=100000000 src/main.c src/sha256.c -o $BIN_FULL || exit 1
$CC -Wall -Werror -O1 test/sha256_test.c src/sha256.c -o /tmp/smsha || exit 1

U=1a2b3c4d
SAVE=$F/user/home/$U/savedata/CUSA00419
SNAPS=$F/mnt/usb1/SaveMirror/CUSA00419/$U
PID=""

fresh() {             # $1 = with marker (1/0), $2 = mounted (1/0)
  stop_bin; rm -rf $F
  mkdir -p $SAVE $F/data $F/mnt/usb0 $F/mnt/usb1 $F/hooks
  head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
  head -c 96 /dev/urandom > $SAVE/SGTA50000.bin
  [ "${2:-1}" = 1 ] && touch $F/mnt/usb1/.fake_mountpoint
  # an existing Apollo backup that must never change
  mkdir -p "$F/mnt/usb1/PS4/APOLLO/1a2b3c4d_CUSA00419_SGTA50000"
  head -c 70000 /dev/urandom > "$F/mnt/usb1/PS4/APOLLO/1a2b3c4d_CUSA00419_SGTA50000/SGTA50000"
  if [ "${1:-1}" = 1 ]; then
    mkdir -p $F/mnt/usb1/SaveMirror
    cp usb_template/SaveMirror/ENABLE_SAVEMIRROR.txt usb_template/SaveMirror/CONTROL.txt $F/mnt/usb1/SaveMirror/
  fi
  : > $F/fake_mounts.txt
}
start_bin() { "${1:-$BIN}" > $F/out.log 2>&1 & PID=$!; }
stop_bin()  { [ -n "$PID" ] && kill $PID 2>/dev/null; wait $PID 2>/dev/null; PID=""; }
complete_count() { ls -d $SNAPS/S*_REST $SNAPS/S*_LIVE 2>/dev/null | wc -l | tr -d ' '; }
wait_for() {          # $1 seconds, $2 condition
  for _ in $(seq 1 $(( $1 * 4 ))); do eval "$2" && return 0; sleep 0.25; done; return 1; }
set_ctl() { sed -i.bak "s/^$1 *=.*/$1 = $2/" $F/mnt/usb1/SaveMirror/CONTROL.txt; }

echo "== T01 SHA-256 implementation"
head -c 3000001 /dev/urandom > /tmp/smsha.bin
check "T01 SHA-256 matches test vectors and system sha256" "/tmp/smsha /tmp/smsha.bin $(sha /tmp/smsha.bin) >/dev/null" "see /tmp/smsha output"

echo "== T02 drive mounted but no marker file"
fresh 0 1; before=$(tree_hash $F/mnt/usb1); start_bin; sleep 5; stop_bin
check "T02 nothing written without SaveMirror/ENABLE_SAVEMIRROR.txt" \
  "[ \"$before\" = \"\$(tree_hash $F/mnt/usb1)\" ] && [ ! -e $F/mnt/usb1/SaveMirror ]" "USB tree changed"
check "T02 user told the drive was not found" "grep -q 'backup drive not found' $F/notify.log" "no notification"

echo "== T03 marker present but /mnt/usb1 is not a mount point (would be internal storage)"
fresh 1 0; before=$(tree_hash $F/mnt/usb1); start_bin; sleep 5; stop_bin
check "T03 nothing written to an unmounted /mnt/usbN directory" \
  "[ \"$before\" = \"\$(tree_hash $F/mnt/usb1)\" ]" "wrote to unmounted dir"

echo "== T04 firmware guard"
fresh 1 1; before=$(tree_hash $F)
SM_FAKE_FW=12020000 $BIN > $F/out.log 2>&1
check "T04 refuses to run on firmware other than 13.52" \
  "grep -q 'unsupported firmware' $F/notify.log && [ ! -e $F/data/savemirror ] && [ ! -e $F/mnt/usb1/SaveMirror/CUSA00419 ]" "ran anyway"

echo "== T05 REST snapshot at start, contents and manifest"
fresh 1 1
src_hash=$(tree_hash $SAVE); apollo=$(tree_hash $F/mnt/usb1/PS4/APOLLO)
start_bin
wait_for 15 '[ "$(complete_count)" -ge 1 ]'
s1=$(ls -d $SNAPS/S*_REST 2>/dev/null | head -1)
check "T05 a REST snapshot is created when the game is closed" "[ -n \"$s1\" ]" "no REST snapshot"
inner="$s1/PS4/SAVEDATA/$U/CUSA00419"
check "T05 files stored in Apollo's encrypted-save layout (sdimg_ prefix removed)" \
  "cmp -s $SAVE/sdimg_SGTA50000 $inner/SGTA50000 && cmp -s $SAVE/SGTA50000.bin $inner/SGTA50000.bin" "content differs"
check "T05 MANIFEST.sha256 verifies with the system sha256 tool" "(cd $s1 && $SHA -c MANIFEST.sha256 >/dev/null)" "manifest failed"
check "T05 INFO.txt ends with status=complete and class=REST" \
  "tail -1 $s1/INFO.txt | grep -q status=complete && grep -q '^class=REST' $s1/INFO.txt" "bad INFO.txt"
check "T05 original save untouched" "[ \"$src_hash\" = \"\$(tree_hash $SAVE)\" ]" "source changed"

check "T05 tools/verify_snapshots.command reports the snapshot OK" \
  "tools/verify_snapshots.command $F/mnt/usb1 </dev/null | grep -q '1 snapshot(s) OK, 0 damaged'" "verify tool failed"
rm -rf /tmp/smdmg && mkdir -p /tmp/smdmg/SaveMirror/CUSA00419/$U && cp -r "$s1" /tmp/smdmg/SaveMirror/CUSA00419/$U/
printf 'Z' | dd of="/tmp/smdmg/SaveMirror/CUSA00419/$U/$(basename $s1)/PS4/SAVEDATA/$U/CUSA00419/SGTA50000" bs=1 seek=100 conv=notrunc 2>/dev/null
check "T05 verify tool detects a corrupted snapshot" \
  "tools/verify_snapshots.command /tmp/smdmg </dev/null | grep -q '0 snapshot(s) OK, 1 damaged'" "corruption missed"

echo "== T06 second instance refuses to start"
$BIN > $F/out2.log 2>&1 & P2=$!
sleep 2
if kill -0 $P2 2>/dev/null; then kill $P2; bad "T06 second instance exits" "still running"
else check "T06 second instance exits (lock held)" "grep -q 'already running' $F/notify.log" "no message"; fi

echo "== T07 LIVE snapshot while the game runs"
echo "/user/home/$U/savedata/CUSA00419/sdimg_SGTA50000 /mnt/sandbox/CUSA00419_000/savedata0" > $F/fake_mounts.txt
echo "/dev/lvd0 /mnt/sandbox/CUSA00419_000/app0" >> $F/fake_mounts.txt
head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
wait_for 20 '[ -n "$(ls -d $SNAPS/S*_LIVE 2>/dev/null)" ]'
l1=$(ls -d $SNAPS/S*_LIVE 2>/dev/null | head -1)
check "T07 LIVE snapshot made after an autosave, labelled best effort" \
  "[ -n \"$l1\" ] && grep -q 'best effort' $l1/INFO.txt && grep -q 'save_mounted=yes' $l1/INFO.txt" "no LIVE snapshot"

echo "== T08 continuously changing save is never copied"
n0=$(complete_count)
for i in $(seq 1 8); do head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000; sleep 1; done
check "T08 no snapshot while the save keeps changing" "[ \"$(complete_count)\" = \"$n0\" ]" "snapshot taken mid-change"
wait_for 20 '[ "$(complete_count)" -gt "$n0" ]'
check "T08 snapshot follows once it is quiet" "[ \"$(complete_count)\" -gt \"$n0\" ]" "no snapshot after quiet"

echo "== T09 drive 'pulled' mid-write (write error)"
n0=$(complete_count); touch $F/hooks/fail_write
head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
wait_for 25 '[ ! -e $F/hooks/fail_write ] && [ "$(complete_count)" -gt "$n0" ]'
check "T09 failed attempt discarded, no .partial left, retry succeeds" \
  "grep -q 'copy failed' $F/data/savemirror/savemirror.log && [ -z \"\$(ls -d $SNAPS/*.partial 2>/dev/null)\" ] && [ \"\$(complete_count)\" -eq \$((n0+1)) ]" "see log"
latest=$(ls -d $SNAPS/S* | sort | tail -1)
check "T09 retried snapshot is byte-identical to the save" \
  "cmp -s $SAVE/sdimg_SGTA50000 $latest/PS4/SAVEDATA/$U/CUSA00419/SGTA50000" "content differs"

echo "== T10 save rewritten mid-copy with size and mtime unchanged"
n0=$(complete_count); touch $F/hooks/mutate_source
head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
wait_for 25 '[ ! -e $F/hooks/mutate_source ]'
sleep 1
check "T10 change detected by the second read, attempt discarded" \
  "grep -q 're-read differs' $F/data/savemirror/savemirror.log && [ \"\$(complete_count)\" = \"$n0\" ]" "torn copy kept"
wait_for 25 '[ "$(complete_count)" -gt "$n0" ]'
latest=$(ls -d $SNAPS/S* | sort | tail -1)
check "T10 next snapshot matches the final save bytes" \
  "cmp -s $SAVE/sdimg_SGTA50000 $latest/PS4/SAVEDATA/$U/CUSA00419/SGTA50000" "mismatch"

echo "== T11 half-written slot (sdimg without .bin) is not copied"
n0=$(complete_count); head -c 5000 /dev/urandom > $SAVE/sdimg_SGTA50001
sleep 7
check "T11 no snapshot while a slot is missing its .bin key file" "[ \"$(complete_count)\" = \"$n0\" ]" "copied unpaired slot"
head -c 96 /dev/urandom > $SAVE/SGTA50001.bin
wait_for 20 '[ "$(complete_count)" -gt "$n0" ]'
check "T11 both slots copied once paired" \
  "ls $(ls -d $SNAPS/S* | sort | tail -1)/PS4/SAVEDATA/$U/CUSA00419 | grep -qx SGTA50001.bin" "slot missing"

echo "== T12 game closes -> REST snapshot of the final state"
: > $F/fake_mounts.txt; n0=$(complete_count)
head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
wait_for 20 '[ "$(complete_count)" -gt "$n0" ]'
check "T12 final snapshot is REST" "ls -d $SNAPS/S* | sort | tail -1 | grep -q _REST" "not REST"

echo "== T13 Apollo backup folder never modified"
check "T13 PS4/APOLLO unchanged after all runs" "[ \"$apollo\" = \"\$(tree_hash $F/mnt/usb1/PS4/APOLLO)\" ]" "APOLLO changed"

echo "== T14 stage newest REST snapshot for Apollo (on request only)"
check "T14 PS4/SAVEDATA not created unless requested" "[ ! -e $F/mnt/usb1/PS4/SAVEDATA ]" "created unasked"
set_ctl stage_for_apollo yes
wait_for 15 '[ -e $F/mnt/usb1/PS4/SAVEDATA/$U/CUSA00419/SGTA50000 ]'
rest=$(ls -d $SNAPS/S*_REST | sort | tail -1)
check "T14 staged files equal newest REST snapshot" \
  "diff -r $rest/PS4/SAVEDATA/$U/CUSA00419 $F/mnt/usb1/PS4/SAVEDATA/$U/CUSA00419 >/dev/null" "staged differs"
echo "user-change" > $F/mnt/usb1/PS4/SAVEDATA/$U/CUSA00419/marker.txt
staged=$(tree_hash $F/mnt/usb1/PS4/SAVEDATA); sleep 4
check "T14 existing staged folder is never overwritten" "[ \"$staged\" = \"\$(tree_hash $F/mnt/usb1/PS4/SAVEDATA)\" ]" "overwritten"
set_ctl stage_for_apollo no

echo "== T15 self-install from USB Payloads/ folder"
mkdir -p $F/mnt/usb1/Payloads; printf 'ELF-v1' > $F/mnt/usb1/Payloads/gta5_savemirror.elf
wait_for 10 '[ -e $F/data/payloads/gta5_savemirror.elf ]'
check "T15 payload copied to /data/payloads when missing" "cmp -s $F/mnt/usb1/Payloads/gta5_savemirror.elf $F/data/payloads/gta5_savemirror.elf" "not installed"
printf 'ELF-v2' > $F/mnt/usb1/Payloads/gta5_savemirror.elf; sleep 4
check "T15 different installed payload not replaced without update_payload=yes" "grep -q v1 $F/data/payloads/gta5_savemirror.elf" "replaced"
set_ctl update_payload yes
wait_for 10 'grep -q v2 $F/data/payloads/gta5_savemirror.elf'
check "T15 replaced when update_payload=yes, old kept as .old" "grep -q v2 $F/data/payloads/gta5_savemirror.elf && grep -q v1 $F/data/payloads/gta5_savemirror.elf.old" "not updated"
set_ctl update_payload no

echo "== T16 drive remounted at a different usbN"
n0=$(complete_count)
mv $F/mnt/usb1 /tmp/smusb && mkdir -p $F/mnt/usb1 && mv /tmp/smusb/* /tmp/smusb/.fake_mountpoint $F/mnt/usb0/ 2>/dev/null; rmdir /tmp/smusb 2>/dev/null
SNAPS=$F/mnt/usb0/SaveMirror/CUSA00419/$U
head -c 1500000 /dev/urandom > $SAVE/sdimg_SGTA50000
wait_for 20 '[ "$(complete_count)" -gt "$n0" ]'
check "T16 continues on /mnt/usb0, nothing written to the now-empty /mnt/usb1" \
  "[ \"\$(complete_count)\" -gt \"$n0\" ] && [ -z \"\$(ls -A $F/mnt/usb1)\" ]" "see log"

echo "== T17 stop = yes in CONTROL.txt"
sed -i.bak 's/^stop *=.*/stop = yes/' $F/mnt/usb0/SaveMirror/CONTROL.txt
wait_for 8 '! kill -0 $PID 2>/dev/null'
check "T17 payload exits when stop = yes" "! kill -0 $PID 2>/dev/null" "still running"
PID=""

echo "== T18b uninstall = yes"
fresh 1 1; start_bin; wait_for 15 '[ "$(complete_count)" -ge 1 ]'
mkdir -p $F/data/payloads; echo elf > $F/data/payloads/gta5_savemirror.elf; echo keep > $F/data/payloads/other.elf
snaps_before=$(tree_hash $SNAPS)
set_ctl uninstall yes
wait_for 10 '! kill -0 $PID 2>/dev/null'; PID=""
check "T18b uninstall removes only our internal files and exits; backups kept" \
  "[ ! -e $F/data/payloads/gta5_savemirror.elf ] && [ -e $F/data/payloads/other.elf ] && [ ! -e $F/data/savemirror ] && [ \"$snaps_before\" = \"\$(tree_hash $SNAPS)\" ]" "see tree"

echo "== T18 low free space"
fresh 1 1; start_bin $BIN_FULL; sleep 6; stop_bin
check "T18 no snapshot when free space is below the minimum" \
  "[ \"\$(complete_count)\" = 0 ] && grep -q 'nearly full' $F/notify.log" "wrote anyway"

echo "== T19 retention policy (synthetic 240 snapshots over 130 dates)"
stop_bin; rm -rf $F; R=$F/ret; mkdir -p $R
python3 - "$R" <<'PY'
import os, sys, datetime, random
r = sys.argv[1]; random.seed(7)
d0 = datetime.date(2026, 1, 1); seq = 0; names = []
for day in range(130):
    for k in range(random.choice([1, 1, 2, 3])):
        seq += 1
        cls = random.choice(["REST", "LIVE", "LIVE"])
        n = "S%06d_%s_%02d-00-00_%s" % (seq, (d0 + datetime.timedelta(days=day)).isoformat(), k, cls)
        os.makedirs(os.path.join(r, n)); open(os.path.join(r, n, "INFO.txt"), "w").write("x=1\nstatus=complete\n")
        names.append(n)
# all-LIVE at the end so "newest REST" is older than the newest 40
for k in range(45):
    seq += 1
    n = "S%06d_2026-05-11_%02d-%02d-00_LIVE" % (seq, k // 60, k % 60)
    os.makedirs(os.path.join(r, n)); open(os.path.join(r, n, "INFO.txt"), "w").write("status=complete\n")
    names.append(n)
os.makedirs(os.path.join(r, "S%06d_2026-05-11_23-59-59_LIVE.partial" % (seq + 1)))      # interrupted
os.makedirs(os.path.join(r, "S%06d_2026-05-11_23-59-58_LIVE" % (seq + 2)))              # incomplete
os.makedirs(os.path.join(r, "PS4"))                                                    # foreign
# expected keep-set, computed independently
snaps = sorted(names, key=lambda n: -int(n[1:7]))
keep = set(snaps[:40]); dates = []
for n in snaps:
    d = n[8:18]
    if d not in dates:
        dates.append(d)
        if len(dates) <= 90: keep.add(n)
keep.add(next(n for n in snaps if n.endswith("REST")))
open(r + ".expected", "w").write("\n".join(sorted(keep)) + "\n")
PY
$BIN --prune-only $R >/dev/null
ls $R | grep -E '^S[0-9]{6}_.*_(REST|LIVE)$' | grep -v '23-59-58' | sort > $R.actual
check "T19 keeps newest 40 + newest per day for 90 days + newest REST, nothing else" "diff -q $R.expected $R.actual >/dev/null" "diff $R.expected $R.actual"
check "T19 interrupted .partial removed; incomplete and foreign folders left alone" \
  "[ -z \"\$(ls -d $R/*.partial 2>/dev/null)\" ] && [ -d $R/PS4 ] && ls $R | grep -q 23-59-58" "wrong cleanup"

echo "== T20 every path mentioned in README.md exists in the repository"
missing=""
for p in $(grep -oE '(usb_template|src|test|tools|docs)/[A-Za-z0-9_./-]+' README.md | sed 's/[.,)]*$//' | sort -u); do
  [ -e "$p" ] || missing="$missing $p"
done
for p in gta5_savemirror.elf build_mac.sh SHA256SUMS BUILD_INFO.txt VERSION; do [ -e "$p" ] || missing="$missing $p"; done
check "T20 README paths exist" "[ -z \"$missing\" ]" "missing:$missing"

stop_bin
echo
echo "================ SUMMARY ================"
printf '%s\n' "${RESULTS[@]}"
echo "passed: $PASS   failed: $FAIL"
[ $FAIL = 0 ]
