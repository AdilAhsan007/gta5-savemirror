# Changelog

## 1.0.0-rc2 – 2026-10-30
- Fixed (A): writing is refused when the drive or its free space cannot be verified.
- Fixed (B): MANIFEST/INFO streams are always closed; any flush/sync/close
  error discards the snapshot.
- Fixed (C): Apollo staging uses PS4/SAVEDATA/<16-hex account ID>/ from
  sceUserServiceGetNpAccountId; never the local user ID; skipped if unknown.
- Fixed (D): periodic SHA-256 content check catches same-size/same-mtime changes.
- Changed: snapshot files now in encrypted/; INFO.txt lists local_user_id and account_id.
- New host tests T21–T24; test runs refuse to overlap.

## 1.0.0-rc1 – 2026-10-30
- Fixed: build script now uses the 13.52-capable crt1.o (SDK 573b4a0) on top
  of release v0.9; v0.9 alone cannot run on 13.52.
- Fixed: one consistent install path, `/data/payloads/`, everywhere.
  `payloads.ini.example` removed; the LaunchPad writes that file.
- Fixed: repository layout (`src/`, `test/`, `usb_template/`, `docs/`, `tools/`).
- Fixed: host tests run from a clean checkout (`test/run_host_tests.sh`).
- New: snapshots use Apollo's encrypted-save layout and can be opened in
  Apollo (`stage_for_apollo`).
- New: SHA-256 manifests, second read of the source, mount-state check,
  REST/LIVE classes, sequence-numbered names, mount-point check for USB.
- New: firmware guard (13.52 only), `CONTROL.txt`, self-install from USB,
  `uninstall`, Mac verification tool.
- Removed: process-wide signal/priority/credential changes.
- See docs/AUDIT.md.

## 1.0.0 – 2026-10-30
- First version (unreleased candidate).
