#!/usr/bin/env bash
# Builds gta5_savemirror.elf from source.
#
# macOS: needs Homebrew (https://brew.sh); this script installs llvm@18.
# Linux: run with  SKIP_BREW=1 LLVM_CONFIG=/usr/bin/llvm-config-18 ./build_mac.sh
#
# Toolchain recipe (same as Control4Free's 13.52-tested build):
#   ps4-payload-dev SDK release v0.9 (libraries, headers, wrappers)
#   + crt1.o rebuilt from SDK commit 573b4a0 (adds firmware 13.52 offsets;
#     release v0.9 does NOT know 13.52 and its payloads quit before main()).
set -euo pipefail

SDK_TAG=v0.9
SDK_ZIP_SHA256=3190e88255a72161e5ce2f22a8ae8f638a2c5a9d1ff1e0209ed692d36b4d9ec5
CRT_COMMIT=573b4a0d0d5fa8695cfeee5f5e2f0447c550035d
CRT_TGZ_SHA256=9551320c52409de3bd15acc8cb8807591813748409ae4e7bac7a69b0e7288c4d

cd "$(dirname "$0")"
REPO=$(pwd)
WORK="${SM_SDK_DIR:-$HOME/.gta5-savemirror-sdk}/$SDK_TAG-${CRT_COMMIT:0:7}"
SDK="$WORK/ps4-payload-sdk"

if command -v sha256sum >/dev/null; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
verify() { echo "$2  $1" | $SHA -c - >/dev/null || { echo "Checksum mismatch for $1"; exit 1; }; }

if [ -z "${SKIP_BREW:-}" ]; then
  command -v brew >/dev/null || { echo "Install Homebrew first: https://brew.sh"; exit 1; }
  brew list llvm@18 >/dev/null 2>&1 || brew install llvm@18
  export LLVM_CONFIG="$(brew --prefix llvm@18)/bin/llvm-config"
fi
: "${LLVM_CONFIG:?set LLVM_CONFIG to an LLVM 18 llvm-config}"
export LLVM_CONFIG

if [ ! -f "$SDK/.crt-$CRT_COMMIT" ]; then
  echo "== Preparing SDK in $WORK"
  rm -rf "$WORK"; mkdir -p "$WORK"
  curl -fsSL -o "$WORK/sdk.zip" \
    "https://github.com/ps4-payload-dev/sdk/releases/download/$SDK_TAG/ps4-payload-sdk.zip"
  verify "$WORK/sdk.zip" "$SDK_ZIP_SHA256"
  unzip -q "$WORK/sdk.zip" -d "$WORK"
  chmod -R +x "$SDK/bin"
  curl -fsSL -o "$WORK/crt.tgz" \
    "https://github.com/ps4-payload-dev/sdk/archive/$CRT_COMMIT.tar.gz"
  verify "$WORK/crt.tgz" "$CRT_TGZ_SHA256"
  mkdir -p "$WORK/src" && tar xzf "$WORK/crt.tgz" -C "$WORK/src" --strip-components=1
  make -C "$WORK/src/crt" LLVM_CONFIG="$LLVM_CONFIG" DESTDIR="$SDK" install
  touch "$SDK/.crt-$CRT_COMMIT"
fi

export PS4_PAYLOAD_SDK="$SDK"
echo "== Building"
make -C "$REPO" clean all
echo "== Result"
$SHA "$REPO/gta5_savemirror.elf"
"$("$LLVM_CONFIG" --bindir)/llvm-readelf" -d "$REPO/gta5_savemirror.elf" | grep NEEDED
echo "Compare the SHA-256 above with SHA256SUMS. A different LLVM 18.x build can"
echo "produce a different but equivalent binary; see BUILD_INFO.txt."
