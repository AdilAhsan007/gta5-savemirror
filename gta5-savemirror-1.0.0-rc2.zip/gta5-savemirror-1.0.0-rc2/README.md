# GTA V Save Mirror 1.0.0-rc2

Automatic, offline backups of GTA V (CUSA00419) saves to an exFAT USB drive,
for a PS4 on firmware **13.52** with **GoldHEN v2.4b18.12**.

> **Status: release candidate, not yet run on a real PS4.**
> The payload compiles, its logic passes all host-side tests on a simulated
> PS4 file tree, and its start-up code is the same build that another
> project reports working on 13.52 + GoldHEN v2.4b18.12. None of that proves
> it works on your console. Follow the **First test** below before trusting
> it, and keep making Apollo backups.

## What it does

- Runs in the background, started by GoldHEN's AutoRun. It is a payload,
  not a plugin, so it never runs inside GTA V.
- Every 15 seconds it looks at the names, sizes and dates of GTA V's save
  files (`/user/home/<user>/savedata/CUSA00419/`). Every 5 minutes, if
  nothing seems to have changed, it also reads the files completely and
  compares their SHA-256, so a change that keeps size and date is still
  caught. It only ever **reads** the save.
- When they changed and then stayed unchanged for a while, it copies them to a
  new folder on the USB drive, checks every byte with SHA-256, and only then
  marks the snapshot complete.
- Two kinds of snapshot:
  - **REST**: GTA V was closed and its save was not mounted. These are the
    ones to trust. One is made at every boot (if the save changed) and soon
    after you quit the game.
  - **LIVE**: taken during play, about 90 seconds after an autosave.
    Best effort only: the files on disk may not include what the game still
    holds in memory.
- Keeps the newest 40 snapshots, the newest snapshot of each of the last 90
  days, and always the newest REST snapshot. Older ones are removed.
- Writes nothing unless the drive contains `SaveMirror/ENABLE_SAVEMIRROR.txt`.
  Never touches `PS4/APOLLO` (your Apollo backups).

Snapshots look like this on the drive:

```
SaveMirror/CUSA00419/<user-id>/S000012_2026-10-30_21-15-04_REST/
    encrypted/SGTA50000        (the encrypted save, unchanged)
    encrypted/SGTA50000.bin    (its key file, unchanged)
    MANIFEST.sha256
    INFO.txt                   (local user ID, account ID, REST/LIVE, ...)
```

(The file names depend on what GTA V uses; the above is only an example.)

## Install (about 15 minutes)

You need: this release unzipped on your Mac, your exFAT drive, the PS4.

1. **Copy the template to the drive.** Open `usb_template` on the Mac. Copy
   the **`SaveMirror`** folder and the **`Payloads`** folder to the top level
   (root) of the exFAT drive.
   - If the drive already has a folder called `Payloads`, do **not** drag the
     folder (the Mac would replace it). Open `usb_template/Payloads` and copy
     only `gta5_savemirror.elf` into the existing `Payloads` folder.
   - Do not touch the `PS4` folder on the drive.
2. **For the first test only:** open `SaveMirror/CONTROL.txt` on the drive with
   TextEdit, change `stage_for_apollo = no` to `stage_for_apollo = yes`, and
   save.
3. Eject the drive in Finder, then plug it into the PS4.
4. On the PS4, make sure GTA V is **closed**. Open the GoldHEN menu, then
   **Utilities → Payloads → LaunchPad**. If the LaunchPad is missing or empty,
   turn on **PayLoader** in GoldHEN's Server Settings and try again.
5. **Start it once:**
   - **USB route (no network):** if the LaunchPad lists `gta5_savemirror.elf`
     from the USB drive, select it to run it. On first run it copies itself to
     the PS4's internal folder `/data/payloads/`. You should see
     *"Save Mirror installed to /data/payloads"* and
     *"GTA V Save Mirror running"*.
   - **FTP route (only if the LaunchPad does not show USB payloads):** enable
     GoldHEN's FTP server, connect from the Mac with Cyberduck or FileZilla to
     the PS4's IP address, port 2121. Create the folder `/data/payloads` if it
     does not exist and upload `gta5_savemirror.elf` into it. Turn FTP off
     again. Then select `gta5_savemirror.elf` in the LaunchPad.
   - Do **not** send the payload to GoldHEN's network port 9090.
6. Continue with **First test** below. Add AutoRun only after it passes.

## First test (do not skip)

1. Wait about one minute with GTA V closed. Expected notifications:
   *"GTA V save backed up (REST)"*, then
   *"Snapshot S000001_… is ready in Apollo (USB Saves)"*.
   If instead you see *"Apollo staging skipped: account ID unknown"*, the
   backup still worked but the PS4 did not report an account ID for your
   user (see **Account ID** below). Skip step 2.
   No notification at all within 2 minutes means it is not working: see
   **If something goes wrong**.
2. Open **Apollo Save Tool → USB Saves**. A Grand Theft Auto V entry should
   appear from `PS4/SAVEDATA`. Open it and check that it shows the save's
   details (for example *Marriage Counseling*).
   **This proves the console can open the backup.** Do not copy it to the
   HDD. Close Apollo.
   A warning icon, or no entry at all, means the snapshot could not be
   opened. Stop here and keep using Apollo manually.
3. Start GTA V and play until it autosaves. About 90 seconds later you should
   see *"GTA V save backed up (LIVE, best effort)"*. Quit the game. Within
   about a minute you should see *"GTA V save backed up (REST)"*.
4. Turn the PS4 off, plug the drive into the Mac, and check:
   - `SaveMirror/savemirror.log` lists the snapshots and no errors.
   - New folders exist in `SaveMirror/CUSA00419/<user-id>/`.
   - Optional: double-click `tools/verify_snapshots.command` from this
     release and choose the drive. It re-checks every snapshot's SHA-256.
5. Clean up the test:
   - In `SaveMirror/CONTROL.txt`, set `stage_for_apollo = no`.
   - Delete only the folder `PS4/SAVEDATA/<account-id>/CUSA00419` on the
     drive (the staged copy; `<account-id>` is the 16-character name shown in
     `SaveMirror/savemirror.log`). Leave `PS4/APOLLO` alone.

## Turn on AutoRun

1. GoldHEN → **Utilities → Payloads → LaunchPad**.
2. Highlight the **internal** copy (`/data/payloads/gta5_savemirror.elf`), not
   the one on the USB drive, and press **Square → Add to AutoRun queue**.
3. Open the **AutoRun queue** and check there is exactly one ticked entry for
   `/data/payloads/gta5_savemirror.elf`.
4. Restart the PS4 and load GoldHEN as usual. *"GTA V Save Mirror running"*
   should appear without you doing anything.

GoldHEN stores this queue in `/data/GoldHEN/payloads.ini`. Let the LaunchPad
edit it; there is no need to edit it by hand.

## Daily use

Nothing to do. Play normally. You will see a short notification after each
backup (set `quiet = yes` in `CONTROL.txt` to hide them). The Mac does not need
to be on.

## Settings: `SaveMirror/CONTROL.txt`

| Setting | What `yes` does |
|---|---|
| `stop` | The payload exits within 15 s. Set back to `no`, or it stops again after every restart. |
| `quiet` | No backup notifications. |
| `stage_for_apollo` | Copies the newest REST snapshot to `PS4/SAVEDATA/<account-id>/CUSA00419/` so Apollo can open it. Never overwrites: delete that folder before staging again. |
| `update_payload` | Replaces the internal payload with `Payloads/gta5_savemirror.elf` from the drive when they differ. |
| `uninstall` | Deletes the payload and its state from internal storage, then exits. |

## Account ID

Apollo looks for encrypted USB saves in `PS4/SAVEDATA/<account-id>/`,
where `<account-id>` is the 16-hex-digit PSN account ID (real or
offline-activated), not the 8-digit local user ID in `/user/home`. The
payload asks the PS4 for it with the same system call Apollo uses, offline.
If the PS4 returns no ID (for example the user was never activated), the
payload still makes backups but does **not** stage them for Apollo; it never
guesses. You can then stage by hand: Apollo shows your account ID under
*User Tools / About*; on the Mac create `PS4/SAVEDATA/<that ID>/CUSA00419/`
and copy the files from a snapshot's `encrypted` folder into it.

## Restoring a save

See `docs/RESTORE.md`. Short version: stage the snapshot for Apollo, then use
Apollo to copy it back to the HDD, after first making a fresh Apollo backup.
Raw snapshots only work on **this** PS4 and **this** user.

## Uninstall / roll back

1. GoldHEN → Utilities → Payloads → LaunchPad → **AutoRun queue**: select
   `gta5_savemirror.elf` and remove it (Square), or untick it.
2. On the Mac, set `uninstall = yes` in `SaveMirror/CONTROL.txt`. Plug the
   drive in and start the payload once more from the LaunchPad. It deletes
   `/data/payloads/gta5_savemirror.elf` and `/data/savemirror/` and exits.
   (Or delete those two over FTP instead.)
3. Restart the PS4. Nothing of the payload runs any more.
4. Your backups stay on the drive in `SaveMirror/`. Delete that folder on the
   Mac if you no longer want them. Your Apollo backups are never affected.

Quick pause without uninstalling: `stop = yes` in `CONTROL.txt`.

## If something goes wrong

| What you see | Meaning |
|---|---|
| No notification at all after starting it | The payload did not start (or GoldHEN did not run it). Remove it from AutoRun and report it; keep using Apollo. |
| *"unsupported firmware - not running"* | The payload only runs on 13.52. |
| *"backup drive not found"* | `SaveMirror/ENABLE_SAVEMIRROR.txt` is missing or the drive is not mounted. |
| *"already running"* | A second copy was started; the first keeps working. |
| *"backup drive nearly full"* | Less than 2 GB would remain; nothing was written. |
| *"cannot read free space"* / *"backup drive not verified"* | The drive could not be checked; nothing was written (fail-safe). |
| *"no access to saves"* | GoldHEN did not give the payload access to `/user/home`; nothing was written. |

Logs: `SaveMirror/savemirror.log` on the drive.

## For developers

- Source: `src/main.c`, `src/sha256.c`, `src/sha256.h`, `src/platform.h`
- Build: `./build_mac.sh` (macOS, Homebrew). Details in `BUILD_INFO.txt`.
- Host tests (Linux): `test/run_host_tests.sh`
- Firmware/SDK investigation: `docs/COMPATIBILITY.md`
- Code audit and changes: `docs/AUDIT.md`, `CHANGELOG.md`
- When uploading to GitHub, use GitHub Desktop or `git push`. The web
  uploader can flatten folders (that is what broke `usb_template/` and
  `test/` in commit b684be7).

License: GPL-3.0-or-later (see `LICENSE`); the SDK runtime linked into the
payload is GPLv3+.
