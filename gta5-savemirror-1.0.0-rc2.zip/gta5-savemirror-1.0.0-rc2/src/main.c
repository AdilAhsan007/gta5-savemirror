/* GTA V Save Mirror - offline, read-only GTA V save snapshotter.
 *
 * A GoldHEN ELF payload (PayLoader LaunchPad / AutoRun). It is NOT a plugin
 * and never runs inside GTA V. Note: GoldHEN's PayLoader runs ELF payloads
 * on a thread inside an existing *system* process, so this program must not
 * change process-wide state (signals, priority, credentials, cwd, exit()).
 *
 * What it reads : /user/home/<user>/savedata/CUSA00419/   (never written)
 * What it writes: <USB>/SaveMirror/...                       (snapshots, logs)
 *                 <USB>/PS4/SAVEDATA/<account-id>/CUSA00419/ (ONLY on request)
 *                 /data/savemirror/                          (lock, state, log)
 *                 /data/payloads/gta5_savemirror.elf         (ONLY self-install)
 * It never opens anything under <USB>/PS4/APOLLO.
 *
 * Built with the ps4-payload-dev SDK (GPLv3+), so this file is GPLv3+.
 */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "sha256.h"
#include "platform.h"

#ifdef HOST_TEST
#include "../test/host_platform.h"
#else
#include <ps4/kernel.h>
#endif

#define SM_VERSION "1.0.0-rc2"

/* ------------------------------------------------------------------ */
/* Settings (the #ifndef ones are shortened by the host tests only)    */
/* ------------------------------------------------------------------ */
#define TITLE_ID           "CUSA00419"
#define REQUIRED_FW        0x1352      /* firmware 13.52; nothing else     */
#ifndef POLL_SECS
#define POLL_SECS          15
#endif
#ifndef STABLE_REST_SECS
#define STABLE_REST_SECS   30          /* game closed, save unmounted      */
#endif
#ifndef STABLE_LIVE_SECS
#define STABLE_LIVE_SECS   90          /* game running / save mounted      */
#endif
#define KEEP_RECENT        40
#define KEEP_DAILY_DAYS    90
#ifndef MIN_FREE_MB
#define MIN_FREE_MB        2048
#endif
#define MAX_USB            8
#ifndef CONTENT_CHECK_SECS
#define CONTENT_CHECK_SECS 300         /* full content hash every 5 min    */
#endif
#define MAX_FILES          128
#define MAX_SNAPS          4096
#define COPY_CHUNK         (256 * 1024)
#define LOG_CAP_BYTES      (512 * 1024)

#ifndef ROOT
#define ROOT ""
#endif
#define USER_HOME          ROOT "/user/home"
#define SANDBOX_PREFIX     "/mnt/sandbox/" TITLE_ID "_"
#define STATE_DIR          ROOT "/data/savemirror"
#define LOCK_FILE          STATE_DIR "/instance.lock"
#define PID_FILE           STATE_DIR "/instance.pid"
#define PAYLOAD_DIR        ROOT "/data/payloads"
#define PAYLOAD_NAME       "gta5_savemirror.elf"
#define USB_FMT            ROOT "/mnt/usb%d"
#define MIRROR_DIR         "SaveMirror"
#define MARKER_FILE        "ENABLE_SAVEMIRROR.txt"
#define CONTROL_FILE       "CONTROL.txt"

/* ------------------------------------------------------------------ */
/* Globals                                                             */
/* ------------------------------------------------------------------ */
static char g_usb[256];               /* "/mnt/usbN" of the chosen drive */
static int  g_quiet;
static uint8_t g_buf[COPY_CHUNK];

typedef struct {
  int stop, quiet, stage_for_apollo, update_payload, uninstall;
} control_t;

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */
static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }
static int is_dir(const char *p) {
  struct stat st;
  return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}
static int is_reg(const char *p) {
  struct stat st;
  return lstat(p, &st) == 0 && S_ISREG(st.st_mode);
}
static void mkdir_p(const char *p) {
  char t[512];
  snprintf(t, sizeof t, "%s", p);
  for(char *s = t + 1; *s; s++)
    if(*s == '/') { *s = 0; mkdir(t, 0777); *s = '/'; }
  mkdir(t, 0777);
}
static int starts_with(const char *s, const char *p) {
  return strncmp(s, p, strlen(p)) == 0;
}
static int ends_with(const char *s, const char *x) {
  size_t a = strlen(s), b = strlen(x);
  return a >= b && strcmp(s + a - b, x) == 0;
}

/* Removes a tree. Only ever called on paths built by this program under
 * <USB>/SaveMirror/ (snapshot folders and their .partial leftovers). */
static void rm_tree(const char *p) {
  DIR *d = opendir(p);
  struct dirent *e;
  char c[768];
  if(!d) { unlink(p); return; }
  while((e = readdir(d))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    snprintf(c, sizeof c, "%s/%s", p, e->d_name);
    if(is_dir(c)) rm_tree(c); else unlink(c);
  }
  closedir(d);
  rmdir(p);
}

/* ------------------------------------------------------------------ */
/* Notifications and logging                                           */
/* ------------------------------------------------------------------ */
static void notify(const char *fmt, ...) {
  char msg[512];
  va_list ap;
  if(g_quiet) return;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  platform_notify(msg);
}

static void append_capped(const char *path, const char *line) {
  struct stat st;
  char old[512];
  if(stat(path, &st) == 0 && st.st_size > LOG_CAP_BYTES) {
    snprintf(old, sizeof old, "%s.1", path);
    unlink(old);
    rename(path, old);
  }
  FILE *f = fopen(path, "a");
  if(f) { fputs(line, f); fclose(f); }
}

static void logmsg(const char *fmt, ...) {
  char line[1024], body[900], ts[32], p[512];
  time_t now = time(NULL);
  struct tm tm;
  va_list ap;
  localtime_r(&now, &tm);
  strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", &tm);
  va_start(ap, fmt);
  vsnprintf(body, sizeof body, fmt, ap);
  va_end(ap);
  snprintf(line, sizeof line, "%s %s\n", ts, body);
  append_capped(STATE_DIR "/savemirror.log", line);
  if(g_usb[0]) {
    snprintf(p, sizeof p, "%s/%s/savemirror.log", g_usb, MIRROR_DIR);
    append_capped(p, line);
  }
}

/* ------------------------------------------------------------------ */
/* Mount table: is GTA V running? is its save image mounted?           */
/* ------------------------------------------------------------------ */
typedef struct { int game_running, save_mounted; } gamestate_t;

static sm_mount_t g_mounts[512];

static gamestate_t read_gamestate(void) {
  gamestate_t g = {0, 0};
  int n = platform_mounts(g_mounts, 512);
  for(int i = 0; i < n; i++) {
    const char *on = g_mounts[i].on, *from = g_mounts[i].from;
    if(strstr(on, SANDBOX_PREFIX)) {
      g.game_running = 1;
      if(strstr(on, "/savedata")) g.save_mounted = 1;
    }
    if(strstr(from, "/savedata/" TITLE_ID "/")) g.save_mounted = 1;
  }
  return g;
}

/* ------------------------------------------------------------------ */
/* Choosing the USB drive                                               */
/*  - must be a real mount point (so we never write to internal storage */
/*    through an empty /mnt/usbN directory)                             */
/*  - must contain SaveMirror/ENABLE_SAVEMIRROR.txt                     */
/* ------------------------------------------------------------------ */
static int find_usb(void) {
  char base[256], marker[400];
  for(int i = 0; i < MAX_USB; i++) {
    snprintf(base, sizeof base, USB_FMT, i);
    if(!platform_is_mountpoint(base)) continue;
    snprintf(marker, sizeof marker, "%s/%s/%s", base, MIRROR_DIR, MARKER_FILE);
    if(!is_reg(marker)) continue;
    snprintf(g_usb, sizeof g_usb, "%s", base);
    return 1;
  }
  g_usb[0] = 0;
  return 0;
}

static int usb_still_ok(void) {
  char marker[400];
  if(!g_usb[0] || !platform_is_mountpoint(g_usb)) return 0;
  snprintf(marker, sizeof marker, "%s/%s/%s", g_usb, MIRROR_DIR, MARKER_FILE);
  return is_reg(marker);
}

/* Free space in MB, or -1 if it cannot be determined reliably.
 * Callers treat -1 as "do not write" (fail closed). */
static long long usb_free_mb(void) {
  unsigned long long bavail = 0, bsize = 0;
  if(platform_free_space(g_usb, &bavail, &bsize) != 0) return -1;
  if(bsize == 0 || bsize > (1ull << 24)) return -1;           /* nonsense */
  if(bavail > (~0ull) / bsize) return -1;                     /* overflow */
  return (long long)((bavail * bsize) >> 20);
}

/* CONTROL.txt: "key = yes|no" lines. Unknown lines are ignored. */
static control_t read_control(void) {
  control_t c = {0, 0, 0, 0, 0};
  char p[400], line[256];
  snprintf(p, sizeof p, "%s/%s/%s", g_usb, MIRROR_DIR, CONTROL_FILE);
  FILE *f = fopen(p, "r");
  if(!f) return c;
  while(fgets(line, sizeof line, f)) {
    char key[64] = "", val[64] = "";
    char *eq = strchr(line, '=');
    if(line[0] == '#' || !eq) continue;
    *eq = 0;
    sscanf(line, " %63[A-Za-z_]", key);
    sscanf(eq + 1, " %63[A-Za-z]", val);
    int on = !strcasecmp(val, "yes") || !strcasecmp(val, "true") ||
             !strcasecmp(val, "on") || !strcmp(val, "1");
    if(!strcasecmp(key, "stop")) c.stop = on;
    else if(!strcasecmp(key, "quiet")) c.quiet = on;
    else if(!strcasecmp(key, "stage_for_apollo")) c.stage_for_apollo = on;
    else if(!strcasecmp(key, "update_payload")) c.update_payload = on;
    else if(!strcasecmp(key, "uninstall")) c.uninstall = on;
  }
  fclose(f);
  return c;
}

/* ------------------------------------------------------------------ */
/* The save folder: pairs of  sdimg_<DIR>  +  <DIR>.bin                 */
/* ------------------------------------------------------------------ */
typedef struct {
  char     name[256];
  int64_t  size;
  int64_t  mtime_s;
  int64_t  mtime_ns;
} finfo_t;

typedef struct {
  int      n;
  finfo_t  f[MAX_FILES];
  int      pairs;          /* number of complete sdimg/.bin pairs */
  int      unpaired;       /* files without their partner         */
  uint8_t  fp[32];         /* fingerprint of names/sizes/mtimes   */
} savesig_t;

static int cmp_finfo(const void *a, const void *b) {
  return strcmp(((const finfo_t*)a)->name, ((const finfo_t*)b)->name);
}

static int has_name(const savesig_t *s, const char *n) {
  for(int i = 0; i < s->n; i++) if(!strcmp(s->f[i].name, n)) return 1;
  return 0;
}

/* Returns 0 on success, -1 if missing/unreadable, -2 if too many files. */
static int read_savesig(const char *dir, savesig_t *s) {
  DIR *d = opendir(dir);
  struct dirent *e;
  struct stat st;
  char p[768];
  sha256_ctx h;
  memset(s, 0, sizeof *s);
  if(!d) return -1;
  while((e = readdir(d))) {
    if(e->d_name[0] == '.') continue;
    snprintf(p, sizeof p, "%s/%s", dir, e->d_name);
    if(lstat(p, &st) != 0 || !S_ISREG(st.st_mode)) continue;
    if(s->n >= MAX_FILES) { closedir(d); return -2; }
    finfo_t *fi = &s->f[s->n++];
    snprintf(fi->name, sizeof fi->name, "%s", e->d_name);
    fi->size = st.st_size;
    fi->mtime_s = st.st_mtim.tv_sec;
    fi->mtime_ns = st.st_mtim.tv_nsec;
  }
  closedir(d);
  qsort(s->f, s->n, sizeof s->f[0], cmp_finfo);
  for(int i = 0; i < s->n; i++) {
    const char *nm = s->f[i].name;
    char other[300];
    if(starts_with(nm, "sdimg_")) {
      snprintf(other, sizeof other, "%s.bin", nm + 6);
      if(has_name(s, other)) s->pairs++; else s->unpaired++;
    } else if(ends_with(nm, ".bin")) {
      snprintf(other, sizeof other, "sdimg_%.*s", (int)(strlen(nm) - 4), nm);
      if(!has_name(s, other)) s->unpaired++;
    }
  }
  sha256_init(&h);
  for(int i = 0; i < s->n; i++) {
    sha256_update(&h, s->f[i].name, strlen(s->f[i].name) + 1);
    sha256_update(&h, &s->f[i].size, sizeof s->f[i].size);
    sha256_update(&h, &s->f[i].mtime_s, sizeof s->f[i].mtime_s);
    sha256_update(&h, &s->f[i].mtime_ns, sizeof s->f[i].mtime_ns);
  }
  sha256_final(&h, s->fp);
  return 0;
}

/* ------------------------------------------------------------------ */
/* Hashing and verified copying                                         */
/* ------------------------------------------------------------------ */
static int hash_file(const char *path, int64_t expect, uint8_t out[32]) {
  sha256_ctx h;
  int64_t total = 0;
  ssize_t n;
  int fd = open(path, O_RDONLY);
  if(fd < 0) return -1;
  sha256_init(&h);
  while((n = read(fd, g_buf, sizeof g_buf)) > 0) {
    sha256_update(&h, g_buf, n);
    total += n;
    usleep(1000);
  }
  close(fd);
  if(n < 0 || (expect >= 0 && total != expect)) return -1;
  sha256_final(&h, out);
  return 0;
}

/* Copy src -> dst (dst must not exist). The source is opened O_RDONLY.
 * Returns 0 and the SHA-256 of the bytes read on success. */
static int copy_file(const char *src, const char *dst, int64_t expect,
                     uint8_t out[32]) {
  sha256_ctx h;
  int64_t total = 0;
  ssize_t n;
  int rc = -1;
  int in = open(src, O_RDONLY);
  int fd = in < 0 ? -1 : open(dst, O_WRONLY | O_CREAT | O_EXCL, 0666);
  if(in < 0 || fd < 0) goto done;
  sha256_init(&h);
  while((n = read(in, g_buf, sizeof g_buf)) > 0) {
    sha256_update(&h, g_buf, n);
    if(platform_write(fd, g_buf, n) != n) goto done;
    total += n;
    platform_after_chunk(src, total);
    usleep(2000);                 /* keep disk load low during gameplay */
  }
  if(n < 0 || (expect >= 0 && total != expect)) goto done;
  if(fsync(fd) != 0) goto done;
  sha256_final(&h, out);
  rc = 0;
done:
  if(in >= 0) close(in);
  if(fd >= 0) close(fd);
  return rc;
}

static int is_user_dir(const char *n) {
  if(strlen(n) != 8) return 0;
  for(int i = 0; i < 8; i++)
    if(!strchr("0123456789abcdefABCDEF", n[i])) return 0;
  return 1;
}

/* Flush, sync and ALWAYS close a stream. Returns 0 only if writing,
 * flushing, syncing and closing all succeeded. */
static int close_checked(FILE *f, const char *what) {
  int err = 0;
  if(ferror(f))                         { err = 1; logmsg("%s: write error", what); }
  if(platform_fflush(f) != 0)           { err = 1; logmsg("%s: fflush failed (errno %d)", what, errno); }
  if(platform_fsync(fileno(f)) != 0)    { err = 1; logmsg("%s: fsync failed (errno %d)", what, errno); }
  if(platform_fclose(f) != 0)           { err = 1; logmsg("%s: fclose failed (errno %d)", what, errno); }
  return err ? -1 : 0;
}

/* ------------------------------------------------------------------ */
/* Snapshots                                                            */
/*  <USB>/SaveMirror/CUSA00419/<user>/S000123_2026-10-30_14-23-00_REST/  */
/*     encrypted/<DIR>      (= sdimg_<DIR> on the console, unchanged)    */
/*     encrypted/<DIR>.bin  (its sealed key, unchanged)                  */
/*     MANIFEST.sha256   (shasum -a 256 -c compatible)                   */
/*     INFO.txt          (last line "status=complete")                   */
/* <DIR>/<DIR>.bin is the naming Apollo expects; stage_for_apollo copies  */
/* them to PS4/SAVEDATA/<account-id>/CUSA00419/ when asked.               */
/* ------------------------------------------------------------------ */
typedef struct {
  char name[96];
  long seq;
  char date[11];
  int  rest;
} snapname_t;

/* Accepts only names this program generates. */
static int parse_snap(const char *n, snapname_t *s) {
  int y, mo, d, h, mi, se;
  long seq;
  char cls[8];
  if(strlen(n) >= sizeof s->name) return 0;
  if(sscanf(n, "S%6ld_%4d-%2d-%2d_%2d-%2d-%2d_%4[A-Z]", &seq, &y, &mo, &d,
            &h, &mi, &se, cls) != 8) return 0;
  if(strcmp(cls, "REST") && strcmp(cls, "LIVE")) return 0;
  if(strlen(n) != 32) return 0;   /* S000001_YYYY-MM-DD_hh-mm-ss_REST */
  snprintf(s->name, sizeof s->name, "%s", n);
  s->seq = seq;
  snprintf(s->date, sizeof s->date, "%04d-%02d-%02d", y, mo, d);
  s->rest = !strcmp(cls, "REST");
  return 1;
}

static int cmp_snap_desc(const void *a, const void *b) {
  long x = ((const snapname_t*)a)->seq, y = ((const snapname_t*)b)->seq;
  return x < y ? 1 : x > y ? -1 : 0;
}

static int is_complete_snapshot(const char *dir) {
  char p[768], line[128], last[128] = "";
  snprintf(p, sizeof p, "%s/INFO.txt", dir);
  FILE *f = fopen(p, "r");
  if(!f) return 0;
  while(fgets(line, sizeof line, f)) snprintf(last, sizeof last, "%s", line);
  fclose(f);
  return !strncmp(last, "status=complete", 15);
}

/* Lists complete snapshots (newest first). Removes leftover .partial
 * folders, which can only come from an interrupted earlier attempt. */
static int list_snaps(const char *base, snapname_t *out, int max, int clean) {
  DIR *d = opendir(base);
  struct dirent *e;
  char p[768];
  int n = 0;
  if(!d) return 0;
  while((e = readdir(d))) {
    snapname_t s;
    if(ends_with(e->d_name, ".partial")) {
      char stem[96];
      size_t L = strlen(e->d_name) - 8;
      if(L < sizeof stem) {
        memcpy(stem, e->d_name, L);
        stem[L] = 0;
        if(clean && parse_snap(stem, &s)) {
          snprintf(p, sizeof p, "%s/%s", base, e->d_name);
          rm_tree(p);
          logmsg("removed interrupted attempt %s", e->d_name);
        }
      }
      continue;
    }
    if(!parse_snap(e->d_name, &s) || n >= max) continue;
    snprintf(p, sizeof p, "%s/%s", base, e->d_name);
    if(!is_complete_snapshot(p)) continue;   /* never count or prune these */
    out[n++] = s;
  }
  closedir(d);
  qsort(out, n, sizeof out[0], cmp_snap_desc);
  return n;
}

static snapname_t g_snaps[MAX_SNAPS];

/* Retention: keep the newest KEEP_RECENT, the newest snapshot of each of
 * the KEEP_DAILY_DAYS most recent dates, and always the newest REST one.
 * The newest snapshot is therefore never deleted. */
static void prune(const char *base) {
  int n = list_snaps(base, g_snaps, MAX_SNAPS, 1);
  char lastdate[11] = "";
  int days = 0, rest_kept = 0;
  char p[768];
  for(int i = 0; i < n; i++) {
    int keep = i < KEEP_RECENT;
    if(strcmp(g_snaps[i].date, lastdate)) {
      snprintf(lastdate, sizeof lastdate, "%s", g_snaps[i].date);
      if(++days <= KEEP_DAILY_DAYS) keep = 1;
    }
    if(g_snaps[i].rest && !rest_kept) { keep = 1; rest_kept = 1; }
    if(!keep) {
      snprintf(p, sizeof p, "%s/%s", base, g_snaps[i].name);
      rm_tree(p);
      logmsg("retention: removed %s", g_snaps[i].name);
    }
  }
}

static long next_seq(const char *base) {
  DIR *d = opendir(base);
  struct dirent *e;
  long max = 0;
  if(!d) return 1;
  while((e = readdir(d))) {
    long s;
    if(sscanf(e->d_name, "S%6ld_", &s) == 1 && s > max) max = s;
  }
  closedir(d);
  return max + 1;
}

typedef enum { SNAP_OK, SNAP_RETRY, SNAP_FAIL } snapres_t;

static snapres_t take_snapshot(const char *user, const char *srcdir,
                               const savesig_t *sig, gamestate_t gs,
                               uint8_t content_out[32]) {
  char base[512], name[96], part[640], fin[640], inner[900];
  char src[900], dst[1200], p[1200], ts[32], hex[65], acct[20] = "unknown";
  static uint8_t h1[MAX_FILES][32];
  uint8_t h2[32];
  time_t now = time(NULL);
  struct tm tm;
  static savesig_t after;
  int live = gs.game_running || gs.save_mounted;
  int64_t total = 0;
  uint64_t account = 0;
  FILE *mf = NULL, *inf = NULL;

  for(int i = 0; i < sig->n; i++) total += sig->f[i].size;

  /* fail closed: verified mount, known free space, enough left afterwards */
  if(!usb_still_ok() || !platform_verify_usb(g_usb)) {
    logmsg("backup drive mount could not be verified - not writing");
    notify("GTA V Save Mirror: backup drive not verified - no backup made");
    return SNAP_FAIL;
  }
  long long fmb = usb_free_mb();
  if(fmb < 0) {
    logmsg("free space on %s could not be determined - not writing", g_usb);
    notify("GTA V Save Mirror: cannot read free space - no backup made");
    return SNAP_FAIL;
  }
  long long need_mb = (total + (1 << 20) - 1) >> 20;
  if(fmb - need_mb < MIN_FREE_MB) {
    logmsg("only %lld MB free, snapshot needs %lld MB, %d MB must remain - not writing",
           fmb, need_mb, MIN_FREE_MB);
    notify("GTA V Save Mirror: backup drive nearly full - no backup made");
    return SNAP_FAIL;
  }

  if(platform_account_id(user, &account) == 0 && account != 0)
    snprintf(acct, sizeof acct, "%016llx", (unsigned long long)account);

  snprintf(base, sizeof base, "%s/%s/%s/%s", g_usb, MIRROR_DIR, TITLE_ID, user);
  mkdir_p(base);
  localtime_r(&now, &tm);
  strftime(ts, sizeof ts, "%Y-%m-%d_%H-%M-%S", &tm);
  snprintf(name, sizeof name, "S%06ld_%s_%s", next_seq(base) % 1000000, ts,
           live ? "LIVE" : "REST");
  snprintf(fin, sizeof fin, "%s/%s", base, name);
  snprintf(part, sizeof part, "%s.partial", fin);
  if(exists(fin) || exists(part)) return SNAP_RETRY;   /* never overwrite */

  snprintf(inner, sizeof inner, "%s/encrypted", part);
  mkdir_p(inner);

  /* 1. copy every file, hashing the bytes as they are read */
  for(int i = 0; i < sig->n; i++) {
    const char *nm = sig->f[i].name;
    snprintf(src, sizeof src, "%s/%s", srcdir, nm);
    snprintf(dst, sizeof dst, "%s/%s", inner, starts_with(nm, "sdimg_") ? nm + 6 : nm);
    if(copy_file(src, dst, sig->f[i].size, h1[i])) {
      logmsg("copy failed for %s (errno %d) - attempt discarded", nm, errno);
      goto fail;
    }
  }
  /* 2. names/sizes/mtimes unchanged ... */
  if(read_savesig(srcdir, &after) || memcmp(after.fp, sig->fp, 32)) {
    logmsg("save changed while copying - attempt discarded");
    goto fail;
  }
  /* 3. ... and the same bytes when read a second time */
  for(int i = 0; i < sig->n; i++) {
    snprintf(src, sizeof src, "%s/%s", srcdir, sig->f[i].name);
    if(hash_file(src, sig->f[i].size, h2) || memcmp(h1[i], h2, 32)) {
      logmsg("%s re-read differs - attempt discarded", sig->f[i].name);
      goto fail;
    }
  }
  /* 4. game must not have started/stopped mid-copy */
  gamestate_t gs2 = read_gamestate();
  if(gs2.game_running != gs.game_running || gs2.save_mounted != gs.save_mounted) {
    logmsg("game state changed while copying - attempt discarded");
    goto fail;
  }
  /* 5. every copy on USB must read back identical */
  for(int i = 0; i < sig->n; i++) {
    const char *nm = sig->f[i].name;
    snprintf(dst, sizeof dst, "%s/%s", inner, starts_with(nm, "sdimg_") ? nm + 6 : nm);
    if(hash_file(dst, sig->f[i].size, h2) || memcmp(h1[i], h2, 32)) {
      logmsg("USB copy of %s does not read back correctly - discarded", nm);
      goto fail;
    }
  }
  /* 6. same drive still there? */
  if(!usb_still_ok()) { logmsg("drive changed during copy - discarded"); goto fail; }

  /* 7. manifest, then INFO (whose last line marks completion), then rename */
  snprintf(p, sizeof p, "%s/MANIFEST.sha256", part);
  if(!(mf = platform_fopen(p, "w"))) { logmsg("cannot create MANIFEST"); goto fail; }
  for(int i = 0; i < sig->n; i++) {
    const char *nm = sig->f[i].name;
    sha256_hex(h1[i], hex);
    fprintf(mf, "%s  encrypted/%s\n", hex, starts_with(nm, "sdimg_") ? nm + 6 : nm);
  }
  { FILE *t = mf; mf = NULL; if(close_checked(t, "MANIFEST.sha256")) goto fail; }

  snprintf(p, sizeof p, "%s/INFO.txt", part);
  if(!(inf = platform_fopen(p, "w"))) { logmsg("cannot create INFO"); goto fail; }
  fprintf(inf,
    "program=GTA V Save Mirror %s\n"
    "title=%s\nlocal_user_id=%s\naccount_id=%s\nsource=%s\n"
    "class=%s\nmeaning=%s\n"
    "game_running=%s\nsave_mounted=%s\n"
    "files=%d\npairs=%d\nbytes=%lld\n"
    "rename_note=sdimg_<DIR> on the console is stored as encrypted/<DIR>\n",
    SM_VERSION, TITLE_ID, user, acct, srcdir,
    live ? "LIVE" : "REST",
    live ? "taken while GTA V was running - best effort, not guaranteed consistent"
         : "taken while GTA V was closed and its save was not mounted",
    gs.game_running ? "yes" : "no", gs.save_mounted ? "yes" : "no",
    sig->n, sig->pairs, (long long)total);
  { FILE *t = inf; inf = NULL; if(close_checked(t, "INFO.txt")) goto fail; }
  /* completion marker appended only after everything above is on disk */
  if(!(inf = platform_fopen(p, "a"))) goto fail;
  fputs("status=complete\n", inf);
  { FILE *t = inf; inf = NULL; if(close_checked(t, "INFO.txt status")) goto fail; }

  if(rename(part, fin) != 0) { logmsg("rename failed (errno %d)", errno); goto fail; }
  if(!is_complete_snapshot(fin)) { logmsg("committed snapshot unreadable"); return SNAP_RETRY; }

  /* content fingerprint of what we just saved */
  {
    sha256_ctx c;
    sha256_init(&c);
    for(int i = 0; i < sig->n; i++) {
      sha256_update(&c, sig->f[i].name, strlen(sig->f[i].name) + 1);
      sha256_update(&c, h1[i], 32);
    }
    sha256_final(&c, content_out);
  }
  logmsg("snapshot %s OK (%d files, %lld bytes, %s)", name, sig->n,
         (long long)total, live ? "LIVE" : "REST");
  prune(base);
  return SNAP_OK;

fail:
  if(mf) platform_fclose(mf);
  if(inf) platform_fclose(inf);
  rm_tree(part);              /* our own .partial folder only */
  return SNAP_RETRY;
}

/* Content fingerprint of the live save (all files, in name order). */
static int content_fp(const char *srcdir, const savesig_t *sig, uint8_t out[32]) {
  char src[900];
  uint8_t h[32];
  sha256_ctx c;
  sha256_init(&c);
  for(int i = 0; i < sig->n; i++) {
    snprintf(src, sizeof src, "%s/%s", srcdir, sig->f[i].name);
    if(hash_file(src, sig->f[i].size, h)) return -1;
    sha256_update(&c, sig->f[i].name, strlen(sig->f[i].name) + 1);
    sha256_update(&c, h, 32);
  }
  sha256_final(&c, out);
  return 0;
}

/* ------------------------------------------------------------------ */
/* On request only: put the newest REST snapshot where Apollo looks,    */
/* <USB>/PS4/SAVEDATA/<user>/CUSA00419/. Never overwrites anything.     */
/* ------------------------------------------------------------------ */
static int g_stage_reported;          /* 0 = forget what was reported */
static char g_reported[32][24];
static int g_nreported;

/* Report each (user, reason) once per staging request, not once ever. */
static int first_report(const char *user, char reason) {
  char key[24];
  if(!g_stage_reported) { g_nreported = 0; g_stage_reported = 1; }
  snprintf(key, sizeof key, "%s:%c", user, reason);
  for(int i = 0; i < g_nreported; i++) if(!strcmp(g_reported[i], key)) return 0;
  if(g_nreported < 32) snprintf(g_reported[g_nreported++], sizeof g_reported[0], "%s", key);
  return 1;
}

/* stage_for_apollo = yes: copy the newest REST snapshot of each local user
 * to <USB>/PS4/SAVEDATA/<account-id>/CUSA00419/, the layout of Sony's own
 * USB save export that Apollo scans. The account ID comes from the system
 * (sceUserServiceGetNpAccountId, the same call Apollo uses). If it is not
 * available or is zero, nothing is staged: we never guess a folder name.
 * An existing destination is never overwritten. */
static void stage_for_apollo(void) {
  char users[256], base[640], dest[640], tmp[640], s[1200], d[1200], acct[20];
  DIR *ud;
  struct dirent *ue;
  snprintf(users, sizeof users, "%s/%s/%s", g_usb, MIRROR_DIR, TITLE_ID);
  if(!(ud = opendir(users))) return;
  while((ue = readdir(ud))) {
    uint64_t account = 0;
    if(!is_user_dir(ue->d_name)) continue;
    if(platform_account_id(ue->d_name, &account) != 0 || account == 0) {
      if(first_report(ue->d_name, 'a')) {
        logmsg("staging: no account ID for local user %s - not staged", ue->d_name);
        notify("Apollo staging skipped: account ID unknown (see README)");
      }
      continue;
    }
    snprintf(acct, sizeof acct, "%016llx", (unsigned long long)account);
    snprintf(base, sizeof base, "%s/%s", users, ue->d_name);
    snprintf(dest, sizeof dest, "%s/PS4/SAVEDATA/%s/%s", g_usb, acct, TITLE_ID);
    if(exists(dest)) {
      if(first_report(ue->d_name, 'e')) {
        logmsg("staging: %s already exists - not overwritten", dest);
        notify("Apollo staging: PS4/SAVEDATA/%s/" TITLE_ID " exists - delete it first", acct);
      }
      continue;
    }
    int n = list_snaps(base, g_snaps, MAX_SNAPS, 0), pick = -1;
    for(int i = 0; i < n && pick < 0; i++) if(g_snaps[i].rest) pick = i;
    if(pick < 0) { logmsg("staging: no REST snapshot for %s yet", ue->d_name); continue; }

    char inner[900];
    snprintf(inner, sizeof inner, "%s/%s/encrypted", base, g_snaps[pick].name);
    snprintf(tmp, sizeof tmp, "%s/%s/staging.partial", g_usb, MIRROR_DIR);
    rm_tree(tmp);
    mkdir_p(tmp);
    DIR *fd = opendir(inner);
    struct dirent *fe;
    int ok = fd != NULL;
    while(ok && (fe = readdir(fd))) {
      struct stat st;
      uint8_t a[32], b[32];
      if(fe->d_name[0] == '.') continue;
      snprintf(s, sizeof s, "%s/%s", inner, fe->d_name);
      snprintf(d, sizeof d, "%s/%s", tmp, fe->d_name);
      if(stat(s, &st) || copy_file(s, d, st.st_size, a) ||
         hash_file(d, st.st_size, b) || memcmp(a, b, 32)) ok = 0;
    }
    if(fd) closedir(fd);
    char parent[700];
    snprintf(parent, sizeof parent, "%s/PS4/SAVEDATA/%s", g_usb, acct);
    if(ok) { mkdir_p(parent); ok = rename(tmp, dest) == 0; }
    if(!ok) { rm_tree(tmp); logmsg("staging for Apollo failed"); continue; }
    first_report(ue->d_name, 'e');     /* don't then warn about our own copy */
    logmsg("staged %s (local user %s) for Apollo at %s", g_snaps[pick].name,
           ue->d_name, dest);
    notify("Snapshot %s is ready in Apollo (USB Saves)", g_snaps[pick].name);
  }
  closedir(ud);
}

/* ------------------------------------------------------------------ */
/* Optional self-install: <USB>/Payloads/gta5_savemirror.elf ->         */
/* /data/payloads/gta5_savemirror.elf (only if missing, or if           */
/* update_payload = yes). Lets you avoid FTP entirely.                  */
/* ------------------------------------------------------------------ */
static void self_install(int update) {
  char src[400], dst[400], tmp[420], bak[420];
  struct stat st;
  uint8_t a[32], b[32];
  snprintf(src, sizeof src, "%s/Payloads/%s", g_usb, PAYLOAD_NAME);
  snprintf(dst, sizeof dst, "%s/%s", PAYLOAD_DIR, PAYLOAD_NAME);
  if(stat(src, &st) || !S_ISREG(st.st_mode)) return;
  if(exists(dst)) {
    if(hash_file(src, st.st_size, a) || hash_file(dst, -1, b)) return;
    if(!memcmp(a, b, 32) || !update) return;
  }
  mkdir_p(PAYLOAD_DIR);
  snprintf(tmp, sizeof tmp, "%s.new", dst);
  unlink(tmp);
  if(copy_file(src, tmp, st.st_size, a) || hash_file(tmp, st.st_size, b) ||
     memcmp(a, b, 32)) { unlink(tmp); logmsg("self-install copy failed"); return; }
  if(exists(dst)) { snprintf(bak, sizeof bak, "%s.old", dst); unlink(bak); rename(dst, bak); }
  if(rename(tmp, dst) == 0) {
    logmsg("installed payload to %s", dst);
    notify("Save Mirror installed to /data/payloads - add it to AutoRun");
  }
}

/* uninstall = yes: delete exactly our own files on internal storage and
 * exit. Remove the AutoRun entry in GoldHEN's LaunchPad first. Backups on
 * the USB drive are left alone. */
static void uninstall_self(void) {
  static const char *names[] = {"", ".old", ".new"};
  char p[512];
  for(int i = 0; i < 3; i++) {
    snprintf(p, sizeof p, "%s/%s%s", PAYLOAD_DIR, PAYLOAD_NAME, names[i]);
    unlink(p);
  }
  DIR *d = opendir(STATE_DIR);
  struct dirent *e;
  while(d && (e = readdir(d))) {
    if(e->d_name[0] == '.') continue;
    snprintf(p, sizeof p, "%s/%s", STATE_DIR, e->d_name);
    unlink(p);
  }
  if(d) closedir(d);
  rmdir(STATE_DIR);
}

/* ------------------------------------------------------------------ */
/* Per-user watcher                                                     */
/* ------------------------------------------------------------------ */
/* What "already backed up" means: both the metadata fingerprint (names,
 * sizes, mtimes) AND the content fingerprint (SHA-256 of every file) of
 * the save match the last good snapshot. Metadata is checked every poll;
 * content is re-hashed every CONTENT_CHECK_SECS, so a rewrite that keeps
 * size and mtime is still noticed (Issue D). */
typedef struct {
  char    user[16];
  uint8_t seen[32];         /* metadata fp last observed           */
  time_t  seen_since;       /* when that observation started       */
  uint8_t saved[32];        /* metadata fp of last good snapshot   */
  uint8_t saved_content[32];/* content fp of last good snapshot    */
  int     has_saved;        /* saved + saved_content valid         */
  time_t  last_content_check;
  int     content_dirty;    /* content changed behind unchanged metadata */
  int     warned;
} ustate_t;

static ustate_t g_users[16];
static int g_nusers;

static int parse_hex32(const char *hex, uint8_t out[32]) {
  if(strlen(hex) != 64) return -1;
  for(int i = 0; i < 64; i++) {
    char c = hex[i];
    int v = c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1;
    if(v < 0) return -1;
    out[i / 2] = (uint8_t)((i & 1) ? (out[i / 2] | v) : (v << 4));
  }
  return 0;
}

static ustate_t *get_user(const char *u) {
  for(int i = 0; i < g_nusers; i++)
    if(!strcmp(g_users[i].user, u)) return &g_users[i];
  if(g_nusers >= 16) return NULL;
  ustate_t *s = &g_users[g_nusers++];
  memset(s, 0, sizeof *s);
  snprintf(s->user, sizeof s->user, "%s", u);
  char p[256], h1[80], h2[80];
  snprintf(p, sizeof p, STATE_DIR "/last_%s.txt", u);
  FILE *f = fopen(p, "r");
  if(f) {
    if(fscanf(f, "%70s %70s", h1, h2) == 2 &&
       !parse_hex32(h1, s->saved) && !parse_hex32(h2, s->saved_content))
      s->has_saved = 1;               /* RC1 one-line files are ignored */
    fclose(f);
  }
  return s;
}

static void store_saved(ustate_t *s) {
  char p[256], tmp[270], a[65], b[65];
  snprintf(p, sizeof p, STATE_DIR "/last_%s.txt", s->user);
  snprintf(tmp, sizeof tmp, "%s.new", p);
  sha256_hex(s->saved, a);
  sha256_hex(s->saved_content, b);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  fprintf(f, "%s\n%s\n", a, b);
  if(close_checked(f, "state file") == 0) rename(tmp, p); else unlink(tmp);
}

static savesig_t g_sig;

static void cycle(void) {
  DIR *d;
  struct dirent *e;
  char dir[512];
  time_t now = time(NULL);
  gamestate_t gs = read_gamestate();
  int live = gs.game_running || gs.save_mounted;

  if(!(d = opendir(USER_HOME))) { logmsg("cannot open " USER_HOME); return; }
  while((e = readdir(d))) {
    if(!is_user_dir(e->d_name)) continue;
    snprintf(dir, sizeof dir, USER_HOME "/%s/savedata/" TITLE_ID, e->d_name);
    if(!is_dir(dir)) continue;
    ustate_t *s = get_user(e->d_name);
    if(!s) continue;
    int r = read_savesig(dir, &g_sig);
    if(r == -2) {
      if(!s->warned) logmsg("user %s: more than %d files - not supported", s->user, MAX_FILES);
      s->warned = 1;
      continue;
    }
    if(r || g_sig.pairs == 0) continue;

    if(memcmp(g_sig.fp, s->seen, 32)) {       /* metadata changed: restart clock */
      memcpy(s->seen, g_sig.fp, 32);
      s->seen_since = now;
      continue;
    }
    if(g_sig.unpaired) continue;               /* half-written slot      */
    int meta_same = s->has_saved && !memcmp(g_sig.fp, s->saved, 32);

    /* periodic content check, only when metadata says "nothing new" */
    if(meta_same && !s->content_dirty &&
       now - s->last_content_check >= CONTENT_CHECK_SECS) {
      uint8_t cf[32];
      s->last_content_check = now;
      if(content_fp(dir, &g_sig, cf) == 0 && memcmp(cf, s->saved_content, 32)) {
        logmsg("user %s: content changed with same sizes/mtimes - will back up", s->user);
        s->content_dirty = 1;
        s->seen_since = now;                   /* quiet period starts now */
      }
      continue;
    }
    if(meta_same && !s->content_dirty) continue;              /* up to date */
    if(now - s->seen_since < (live ? STABLE_LIVE_SECS : STABLE_REST_SECS)) continue;

    uint8_t newcontent[32];
    snapres_t res = take_snapshot(s->user, dir, &g_sig, gs, newcontent);
    if(res == SNAP_OK) {
      memcpy(s->saved, g_sig.fp, 32);
      memcpy(s->saved_content, newcontent, 32);
      s->has_saved = 1;
      s->content_dirty = 0;
      s->last_content_check = now;
      store_saved(s);
      notify(live ? "GTA V save backed up (LIVE, best effort)"
                  : "GTA V save backed up (REST)");
    } else {
      s->seen_since = now;                     /* wait a full window again */
    }
  }
  closedir(d);
}

/* ------------------------------------------------------------------ */
/* Single instance                                                      */
/* ------------------------------------------------------------------ */
static int g_lockfd = -1;

static int acquire_lock(void) {
  g_lockfd = open(LOCK_FILE, O_RDWR | O_CREAT, 0666);
  if(g_lockfd < 0) return 0;
  if(flock(g_lockfd, LOCK_EX | LOCK_NB) == 0) return 1;
  if(errno == EWOULDBLOCK) { close(g_lockfd); g_lockfd = -1; return 0; }
  /* flock unsupported: fall back to a heartbeat file (stale after 60 s) */
  struct stat st;
  if(stat(PID_FILE, &st) == 0 && time(NULL) - st.st_mtime < 60) {
    close(g_lockfd); g_lockfd = -1; return 0;
  }
  return 1;
}

static void heartbeat(void) {
  FILE *f = fopen(PID_FILE, "w");
  if(f) { fprintf(f, "%ld\n", (long)time(NULL)); fclose(f); }
}

/* ------------------------------------------------------------------ */
int main(int argc, char **argv) {
  (void)argc; (void)argv;
  unsigned fw = platform_fw_version();

#ifdef HOST_TEST
  if(argc == 3 && !strcmp(argv[1], "--prune-only")) {
    snprintf(g_usb, sizeof g_usb, "x");
    prune(argv[2]);
    return 0;
  }
#endif

  /* Firmware guard: refuse anything that is not 13.52. */
  if((fw >> 16) != REQUIRED_FW) {
    platform_notify("GTA V Save Mirror: unsupported firmware - not running");
    return 0;
  }

  mkdir_p(STATE_DIR);
  if(!acquire_lock()) {
    platform_notify("GTA V Save Mirror is already running");
    return 0;
  }

  if(access(USER_HOME, R_OK) != 0) {
    logmsg("cannot read " USER_HOME " - payload lacks permission; exiting");
    platform_notify("GTA V Save Mirror: no access to saves - not running");
    return 0;
  }

  int have_usb = find_usb();
  logmsg("GTA V Save Mirror %s started, fw 0x%08x, drive %s", SM_VERSION, fw,
         have_usb ? g_usb : "(none)");
  notify(have_usb ? "GTA V Save Mirror running" :
         "GTA V Save Mirror: backup drive not found");

  int warned = !have_usb;
  for(;;) {
    heartbeat();
    if(find_usb()) {
      control_t c = read_control();
      g_quiet = c.quiet;
      if(warned) { logmsg("backup drive found at %s", g_usb); warned = 0; }
      if(c.stop) {
        logmsg("stop = yes in CONTROL.txt - exiting");
        notify("GTA V Save Mirror stopped (CONTROL.txt)");
        break;
      }
      if(c.uninstall) {
        logmsg("uninstall = yes in CONTROL.txt - removing internal files, exiting");
        notify("GTA V Save Mirror uninstalled from internal storage");
        uninstall_self();
        return 0;
      }
      self_install(c.update_payload);
      cycle();
      if(c.stage_for_apollo) stage_for_apollo(); else g_stage_reported = 0;
    } else if(!warned) {
      notify("GTA V Save Mirror: backup drive not found");
      logmsg("backup drive not found - waiting");
      warned = 1;
    }
    sleep(POLL_SECS);
  }
  if(g_lockfd >= 0) close(g_lockfd);
  unlink(PID_FILE);
  return 0;
}

/* ------------------------------------------------------------------ */
/* PS4 platform layer                                                   */
/* ------------------------------------------------------------------ */
#ifndef HOST_TEST
typedef struct notify_request {
  char useless1[45];
  char message[3075];
} notify_request_t;
int sceKernelSendNotificationRequest(int, notify_request_t*, size_t, int);

void platform_notify(const char *msg) {
  notify_request_t req;
  memset(&req, 0, sizeof req);
  snprintf(req.message, sizeof req.message, "%s", msg);
  sceKernelSendNotificationRequest(0, &req, sizeof req, 0);
}
unsigned platform_fw_version(void) { return kernel_get_fw_version(); }
int platform_is_mountpoint(const char *path) {
  struct statfs sf;
  return statfs(path, &sf) == 0 && strcmp(sf.f_mntonname, path) == 0;
}
int platform_verify_usb(const char *path) { return platform_is_mountpoint(path); }
int platform_free_space(const char *path, unsigned long long *bavail,
                        unsigned long long *bsize) {
  struct statfs sf;
  if(statfs(path, &sf) != 0) return -1;
  if(strcmp(sf.f_mntonname, path) != 0) return -1;     /* not that drive */
  if(sf.f_bavail < 0 || sf.f_bsize <= 0) return -1;
  *bavail = (unsigned long long)sf.f_bavail;
  *bsize = (unsigned long long)sf.f_bsize;
  return 0;
}

/* Same system call Apollo uses (settings.c: sceUserServiceGetNpAccountId).
 * Works offline for activated accounts (real or offline-activated). */
int sceUserServiceInitialize(void *params);
int sceUserServiceGetNpAccountId(int32_t user_id, uint64_t *account_id);
int platform_account_id(const char *local_user_hex, uint64_t *account) {
  static int init_done;
  char *end;
  unsigned long uid = strtoul(local_user_hex, &end, 16);
  if(*end || uid == 0 || uid > 0xffffffffUL) return -1;
  if(!init_done) { sceUserServiceInitialize(NULL); init_done = 1; } /* may already be up */
  uint64_t acc = 0;
  if(sceUserServiceGetNpAccountId((int32_t)uid, &acc) != 0) return -1;
  *account = acc;
  return 0;
}
FILE *platform_fopen(const char *p, const char *m) { return fopen(p, m); }
int platform_fflush(FILE *f) { return fflush(f); }
int platform_fsync(int fd) { return fsync(fd); }
int platform_fclose(FILE *f) { return fclose(f); }
int platform_mounts(sm_mount_t *out, int max) {
  static struct statfs sf[160];
  int n = getfsstat(sf, sizeof sf, MNT_NOWAIT);
  if(n < 0) return 0;
  if(n > max) n = max;
  for(int i = 0; i < n; i++) {
    snprintf(out[i].on, sizeof out[i].on, "%s", sf[i].f_mntonname);
    snprintf(out[i].from, sizeof out[i].from, "%s", sf[i].f_mntfromname);
  }
  return n;
}
ssize_t platform_write(int fd, const void *b, size_t n) { return write(fd, b, n); }
void platform_after_chunk(const char *src, int64_t done) { (void)src; (void)done; }
#endif
