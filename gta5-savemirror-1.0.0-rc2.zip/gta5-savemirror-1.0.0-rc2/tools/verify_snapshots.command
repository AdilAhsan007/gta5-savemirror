#!/bin/bash
# Double-click on the Mac (first time: right-click > Open). Checks the
# SHA-256 of every SaveMirror snapshot on the drive you choose.
# Read-only: it never changes anything on the drive.
cd "$(dirname "$0")"
DRIVE=$(osascript -e 'POSIX path of (choose folder with prompt "Choose your backup drive")' 2>/dev/null)
DRIVE=${1:-$DRIVE}
[ -d "$DRIVE/SaveMirror" ] || { echo "No SaveMirror folder on $DRIVE"; read -p "Press Return"; exit 1; }
if command -v shasum >/dev/null; then SHA="shasum -a 256"; else SHA="sha256sum"; fi
good=0; bad=0
for snap in "$DRIVE"/SaveMirror/CUSA00419/*/S*_REST "$DRIVE"/SaveMirror/CUSA00419/*/S*_LIVE; do
  [ -d "$snap" ] || continue
  if tail -1 "$snap/INFO.txt" 2>/dev/null | grep -q status=complete &&
     (cd "$snap" && $SHA -c MANIFEST.sha256 >/dev/null 2>&1); then
    good=$((good+1)); echo "OK      $(basename "$snap")"
  else
    bad=$((bad+1)); echo "DAMAGED $(basename "$snap")"
  fi
done
echo; echo "$good snapshot(s) OK, $bad damaged."
read -p "Press Return to close"
