/* Host (Linux) implementation of src/platform.h, used ONLY by the tests.
 * It simulates the PS4 pieces the payload depends on:
 *   ROOT/mnt/usbN/.fake_mountpoint  -> /mnt/usbN counts as a mounted drive
 *   ROOT/fake_mounts.txt            -> "from on" lines = the mount table
 *   SM_FAKE_FW (env, hex)           -> firmware version (default 0x13520000)
 *   ROOT/hooks/fail_write           -> next write() fails (drive pulled)
 *   ROOT/hooks/mutate_source        -> source changes mid-copy, mtime kept
 *   ROOT/hooks/verify_fail          -> USB mount cannot be verified
 *   ROOT/hooks/statfs_fail          -> free-space query fails
 *   ROOT/hooks/statfs_zero_bsize    -> free-space query returns nonsense
 *   ROOT/hooks/fail_fflush|fail_fsync|fail_fclose -> next call fails once
 *   ROOT/fake_accounts.txt          -> "<local-user> <16-hex account>" lines
 */
#include <sys/statfs.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

void platform_notify(const char *msg) {
  FILE *f = fopen(ROOT "/notify.log", "a");
  if(f) { fprintf(f, "%s\n", msg); fclose(f); }
  printf("[NOTIFY] %s\n", msg);
  fflush(stdout);
}
unsigned platform_fw_version(void) {
  const char *e = getenv("SM_FAKE_FW");
  return e ? (unsigned)strtoul(e, NULL, 16) : 0x13520000u;
}
int platform_is_mountpoint(const char *path) {
  char p[512];
  struct stat st;
  snprintf(p, sizeof p, "%s/.fake_mountpoint", path);
  return stat(p, &st) == 0;
}
int platform_mounts(sm_mount_t *out, int max) {
  FILE *f = fopen(ROOT "/fake_mounts.txt", "r");
  int n = 0;
  if(!f) return 0;
  while(n < max && fscanf(f, "%255s %255s", out[n].from, out[n].on) == 2) n++;
  fclose(f);
  return n;
}
ssize_t platform_write(int fd, const void *b, size_t n) {
  if(access(ROOT "/hooks/fail_write", F_OK) == 0) {
    unlink(ROOT "/hooks/fail_write");
    return -1;                       /* like a pulled USB drive */
  }
  return write(fd, b, n);
}
void platform_after_chunk(const char *src, int64_t done) {
  struct stat st;
  if(done <= 0 || !strstr(src, "/savedata/") ||
     access(ROOT "/hooks/mutate_source", F_OK) != 0) return;
  unlink(ROOT "/hooks/mutate_source");
  stat(src, &st);
  int fd = open(src, O_WRONLY);     /* TEST HOOK ONLY: simulates the game */
  if(fd >= 0) { if(pwrite(fd, "X", 1, 10) != 1) perror("hook"); close(fd); }
  struct timespec ts[2] = {st.st_atim, st.st_mtim};
  utimensat(AT_FDCWD, src, ts, 0);   /* hide the change from size+mtime */
}

static int hook_once(const char *name) {
  char p[512];
  snprintf(p, sizeof p, ROOT "/hooks/%s", name);
  if(access(p, F_OK) != 0) return 0;
  unlink(p);
  return 1;
}
static int hook_on(const char *name) {
  char p[512];
  snprintf(p, sizeof p, ROOT "/hooks/%s", name);
  return access(p, F_OK) == 0;
}
int platform_verify_usb(const char *path) {
  return !hook_on("verify_fail") && platform_is_mountpoint(path);
}
int platform_free_space(const char *path, unsigned long long *bavail,
                        unsigned long long *bsize) {
  struct statfs sf;
  if(hook_on("statfs_fail") || statfs(path, &sf) != 0) return -1;
  *bavail = sf.f_bavail;
  *bsize = hook_on("statfs_zero_bsize") ? 0 : (unsigned long long)sf.f_bsize;
  return 0;
}
int platform_account_id(const char *user, uint64_t *account) {
  FILE *f = fopen(ROOT "/fake_accounts.txt", "r");
  char u[64], a[64];
  int rc = -1;
  if(!f) return -1;
  while(fscanf(f, "%63s %63s", u, a) == 2) {
    if(strcmp(u, user)) continue;
    char *end;
    unsigned long long v = strtoull(a, &end, 16);
    if(*end == 0 && strlen(a) == 16) { *account = v; rc = 0; }
  }
  fclose(f);
  return rc;
}
FILE *platform_fopen(const char *p, const char *m) { return fopen(p, m); }
int platform_fflush(FILE *f) { if(hook_once("fail_fflush")) { errno = EIO; return EOF; } return fflush(f); }
int platform_fsync(int fd) { if(hook_once("fail_fsync")) { errno = EIO; return -1; } return fsync(fd); }
int platform_fclose(FILE *f) {
  int r = fclose(f);                    /* always really closes */
  if(hook_once("fail_fclose")) { errno = EIO; return EOF; }
  return r;
}
