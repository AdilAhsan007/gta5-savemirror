/* Checks src/sha256.c against FIPS 180-4 test vectors and against a file
 * hash given on the command line (computed by the system's sha256sum). */
#include <stdio.h>
#include <string.h>
#include "../src/sha256.h"

static int check(const char *label, const void *d, size_t n, const char *want) {
  sha256_ctx c; uint8_t o[32]; char hex[65];
  sha256_init(&c); sha256_update(&c, d, n); sha256_final(&c, o); sha256_hex(o, hex);
  int ok = !strcmp(hex, want);
  printf("  sha256 %-10s %s\n", label, ok ? "ok" : "MISMATCH");
  return ok;
}

int main(int argc, char **argv) {
  int ok = 1;
  static char mil[1000000];
  memset(mil, 'a', sizeof mil);
  ok &= check("empty", "", 0, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  ok &= check("abc", "abc", 3, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  ok &= check("448bit", "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq", 56,
              "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
  ok &= check("1M x a", mil, sizeof mil,
              "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
  if(argc == 3) {                     /* file, expected hex */
    FILE *f = fopen(argv[1], "rb"); static char b[1 << 20]; size_t n;
    sha256_ctx c; uint8_t o[32]; char hex[65];
    sha256_init(&c);
    while(f && (n = fread(b, 1, 4097, f)) > 0) sha256_update(&c, b, n); /* odd chunks */
    if(f) fclose(f);
    sha256_final(&c, o); sha256_hex(o, hex);
    int fok = !strcmp(hex, argv[2]);
    printf("  sha256 file       %s\n", fok ? "ok" : "MISMATCH");
    ok &= fok;
  }
  return ok ? 0 : 1;
}
