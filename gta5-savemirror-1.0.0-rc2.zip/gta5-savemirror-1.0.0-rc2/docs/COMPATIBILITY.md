# Firmware 13.52 / GoldHEN v2.4b18.12 compatibility

## Which SDK

- ps4-payload-dev SDK, https://github.com/ps4-payload-dev/sdk
- Libraries/headers/wrappers: release **v0.9** (2026-05-12),
  `ps4-payload-sdk.zip`, SHA-256 `3190e882…4d9ec5`.
- Start-up code `crt1.o`: rebuilt from commit
  **573b4a0d0d5fa8695cfeee5f5e2f0447c550035d** (2026-09-22, "Add 14.00
  offsets"), which contains commit 959e4ed "Add 13.52 offsets"
  (Al-Azif, 2026-06-25).
- The 1.0.0 payload I gave you before (SHA-256 `75da1332…`) was built from
  the same commit, but its `build_mac.sh` downloaded release v0.9, which has
  **no 13.52 support** (a payload built that way quits before `main()` on
  13.52). Fixed in this release.

## What the 13.52 entry contains (crt/kernel.c, crt/patch.c)

| Item | 13.52 value | Used by this payload? |
|---|---|---|
| Kernel base from MSR_LSTAR | lstar − 0x1C0 | yes, by the SDK start-up code |
| TARGETID | base + 0x021CC60D | start-up code |
| copyin / copyout | base + 0x2BD790 / 0x2BD6A0 | start-up code (kernel read/write) |
| mmap patches (patch.c) | 0x3B35F0, 0x3B3610, 0x1FC561 | start-up code writes these unconditionally |
| VMSPACE_P_ROOT | **0, marked TODO** | **no** – only used by `kernel_get_vmem_entry` / mprotect helpers, which this payload never calls |

The TODO your review found is real, but it is the same TODO for every
firmware from 3.50 to 14.00 and it only disables an unused helper.

The SDK README still lists 13.52 as **not confirmed** ("[ ] 13.00 …"; 13.50
and 13.52 are not listed at all).

## Evidence that the start-up code works on 13.52 + v2.4b18.12

Control4Free (https://github.com/MoHadiShibli/Control4Free) builds with the
same recipe (release v0.9 + crt1.o from 573b4a0, see its
`docker/Dockerfile`) and lists 13.52 as **tested with GoldHEN v2.4b18.12**
from its version 1.1.1. Its changelog says the payload previously stopped
before doing anything on 13.52 and started working once the crt knew the
13.52 kernel. That is third-party evidence, not my own test.

## What this payload needs from the kernel

- Nothing directly. The only `ps4/kernel.h` function it calls is
  `kernel_get_fw_version()` (a sysctl).
- Version 1.0.0 could write process credentials if `/user/home` was not
  readable. Removed: GoldHEN runs ELF payloads inside an existing system
  process (Control4Free documents ScePartyDaemon), so changing credentials,
  signal handlers or priority would change that system process. The payload
  now just exits if it cannot read the saves.
- The SDK start-up code itself does kernel reads/writes and applies three
  kernel patches with **no "before" check**. If the 13.52 offsets were wrong
  this could crash the console. This is the main residual risk, and is why
  the first test is done with GTA V closed.

## The "HEN 13.52" display

The SDK does not read the text shown in Settings. It reads the kernel's
version number (sysctl 1.38) and picks offsets from that. The payload then
checks that number itself and refuses to run unless it is 13.52, so it
never runs with another firmware's offsets. If GoldHEN ever spoofed that
kernel value, the payload would refuse to run rather than guess.

## Conclusion

13.52 support is **plausible and supported by third-party testing, but not
confirmed by the SDK author and not tested by me**. No other maintained
ELF-payload SDK with 13.52 support was found. GoldHEN's own SDK (syscall 500)
is aimed at plugins/apps and was not needed. Treat the first run as a test.

## rc2 changes affecting compatibility

- Same SDK recipe as rc1 (release v0.9 + crt1.o from 573b4a0), unchanged.
- New import: `libSceUserService.sprx` (`sceUserServiceInitialize`,
  `sceUserServiceGetNpAccountId`), used only to name the Apollo staging
  folder. Control4Free links the same library in a payload tested on 13.52 +
  GoldHEN v2.4b18.12, and GoldHEN v2.4b18.10's changelog fixed
  `sceUserServiceInitialize` failing in ELF payloads. Not tested by me. If
  the call fails, the payload backs up as before and skips staging.
