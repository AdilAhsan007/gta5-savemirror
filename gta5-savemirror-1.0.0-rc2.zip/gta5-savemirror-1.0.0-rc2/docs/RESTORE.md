# Restoring a GTA V save from a SaveMirror snapshot

## What a snapshot is

A snapshot holds the console's own **encrypted** save files, unchanged:

- `<DIR>` = the encrypted save image (`sdimg_<DIR>` on the console)
- `<DIR>.bin` = its sealed key, which only **this** PS4 can unlock

Both files are needed. They work only on the same PS4. Use the same user
(Apollo can re-sign the save's owner details when copying).

This is different from your Apollo backup in `PS4/APOLLO`, which is
decrypted. Keep making those: they are the proven way back.

## Checking a snapshot without risk

- **On the Mac:** `tools/verify_snapshots.command` (or
  `shasum -a 256 -c MANIFEST.sha256` inside a snapshot folder) proves the
  copy is complete and undamaged. It cannot prove the save inside is good,
  because the Mac cannot decrypt it.
- **On the PS4 (real check):** stage the snapshot for Apollo and open it in
  Apollo's USB Saves. If Apollo shows the save's details, the console can
  mount and decrypt it. This reads a *copy* on the USB drive. Your console
  save is not touched.

## Restore with Apollo (recommended)

1. Close GTA V.
2. In Apollo, make a fresh **Copy save game to USB** of the current HDD
   save. This is your undo.
3. Put the snapshot where Apollo looks:
   - Newest REST snapshot: set `stage_for_apollo = yes` in
     `SaveMirror/CONTROL.txt` and wait for *"ready in Apollo"*.
   - An older snapshot: on the Mac, create the folder
     `PS4/SAVEDATA/<account-id>/CUSA00419/` at the top of the drive and copy
     the two files from the snapshot's `encrypted` folder into it.
     `<account-id>` is in the snapshot's `INFO.txt` (`account_id=`) or in
     Apollo's About screen. Do **not** drag a whole `PS4` folder: the Mac
     would replace `PS4/APOLLO`.
4. Apollo → **USB Saves** → the GTA V entry → copy it to the HDD. This
   overwrites the current GTA V save with the snapshot.
5. Start GTA V and check the save. If it is wrong, restore the Apollo
   backup from step 2.

Prefer REST snapshots. LIVE snapshots may be inconsistent.

## Restore by hand over FTP (fallback)

With GTA V closed, upload `encrypted/<DIR>` renamed to `sdimg_<DIR>`, plus
`encrypted/<DIR>.bin`,
to `/user/home/<user-id>/savedata/CUSA00419/`, replacing the files there.
Only for the same PS4 and user. Untested.

## Automatic decrypted backups?

Not done, on purpose. A decrypted copy needs the save to be mounted with
its key. While GTA V is running it already has the save mounted, and a
second mount of the same save could interfere with the game. Instead, you
can turn any REST snapshot into a decrypted Apollo backup on demand: stage
it, then use Apollo's normal **Copy save game** on it.
