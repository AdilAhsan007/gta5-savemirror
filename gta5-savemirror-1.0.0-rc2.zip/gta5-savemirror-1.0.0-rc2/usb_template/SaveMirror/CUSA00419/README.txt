Snapshots appear here as CUSA00419/<user-id>/S000001_<date>_<time>_REST (or _LIVE).
Do not edit snapshot folders.
