This SaveMirror folder belongs at the ROOT of your exFAT backup drive.
It must contain ENABLE_SAVEMIRROR.txt or the payload will not write anything.
See README.md in the release for instructions.
